package com.smart.plant.guardian

import com.smart.plant.guardian.data.model.*
import com.smart.plant.guardian.data.remote.FirebaseSettings
import com.smart.plant.guardian.data.repository.PlantGuardianRepository
import com.smart.plant.guardian.localization.PlantLanguage
import com.smart.plant.guardian.localization.PlantGuardianTranslations
import com.smart.plant.guardian.pairing.DirectDeviceManager
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun testHeartbeatOnlineOfflineThreshold() {
    val now = 1000000L
    val recentSensor = SensorData(
      temperatureC = 25.0,
      humidityPercent = 60.0,
      soilZone1 = 40,
      soilZone2 = 40,
      soilZone3 = 40,
      lightPercent = 50,
      isRaining = false,
      batteryPercent = 90,
      solarCharging = true,
      lastSeenEpochMs = now - 30_000L // 30 seconds ago
    )
    assertTrue("Should be online within 60s", recentSensor.isOnline(now))
    assertEquals(30L, recentSensor.secondsSinceLastSeen(now))

    val staleSensor = recentSensor.copy(lastSeenEpochMs = now - 65_000L) // 65 seconds ago
    assertFalse("Should be offline when older than 60s", staleSensor.isOnline(now))
    assertEquals(65L, staleSensor.secondsSinceLastSeen(now))
  }

  @Test
  fun testSoilMoistureZoneState() {
    val sensor = SensorData(
      temperatureC = 22.0,
      humidityPercent = 55.0,
      soilZone1 = 25, // Below 35 -> DRY
      soilZone2 = 50, // Between 35 and 70 -> GOOD
      soilZone3 = 78, // Above 70 -> WET
      lightPercent = 60,
      isRaining = false,
      batteryPercent = 85,
      solarCharging = true,
      lastSeenEpochMs = System.currentTimeMillis()
    )

    assertEquals(SoilZoneState.DRY, sensor.getZoneState(sensor.soilZone1, 35))
    assertEquals(SoilZoneState.GOOD, sensor.getZoneState(sensor.soilZone2, 35))
    assertEquals(SoilZoneState.WET, sensor.getZoneState(sensor.soilZone3, 35))
    assertEquals(51, sensor.soilAverage)
  }

  @Test
  fun testFirebasePathsAndAppId() {
    val devId = "ESP32-NODE-01"
    val config = FirebaseSettings(
      databaseUrl = "https://smart-plant-rtdb.firebaseio.com",
      appId = "1:123456789:android:abcdef"
    )
    assertEquals("https://smart-plant-rtdb.firebaseio.com/devices/ESP32-NODE-01/sensors.json", config.getSensorsUrl(devId))
    assertEquals("https://smart-plant-rtdb.firebaseio.com/devices/ESP32-NODE-01/status.json", config.getStatusUrl(devId))
    assertEquals("https://smart-plant-rtdb.firebaseio.com/devices/ESP32-NODE-01/commands.json", config.getCommandsUrl(devId))
    assertEquals("https://smart-plant-rtdb.firebaseio.com/devices/ESP32-NODE-01/settings.json", config.getSettingsUrl(devId))
    assertEquals("https://smart-plant-rtdb.firebaseio.com/devices/ESP32-NODE-01/history.json", config.getHistoryUrl(devId))
    assertEquals("1:123456789:android:abcdef", config.appId)
  }

  @Test
  fun testRoleBasedPermissions() {
    val admin = UserProfile("u1", "admin@plant.org", "Admin User", UserRole.ADMIN, UserStatus.ACTIVE)
    val operator = UserProfile("u2", "op@plant.org", "Operator User", UserRole.OPERATOR, UserStatus.ACTIVE)
    val viewer = UserProfile("u3", "view@plant.org", "Viewer User", UserRole.VIEWER, UserStatus.ACTIVE)
    val pending = UserProfile("u4", "pend@plant.org", "New User", UserRole.VIEWER, UserStatus.PENDING)
    val blocked = UserProfile("u5", "bad@plant.org", "Blocked User", UserRole.OPERATOR, UserStatus.BLOCKED)

    assertTrue(admin.isActive)
    assertTrue(operator.isActive)
    assertTrue(viewer.isActive)
    assertFalse(pending.isActive)
    assertFalse(blocked.isActive)
  }

  @Test
  fun testLanguageDictionariesAvailable() {
    val languages = PlantLanguage.entries
    assertEquals(9, languages.size)
    for (lang in languages) {
      val strings = PlantGuardianTranslations.get(lang)
      assertNotNull(strings.appName)
      assertEquals("Smart Plant Guardian", strings.appName)
      assertNotNull(strings.navDashboard)
      assertNotNull(strings.navAddDevice)
      assertNotNull(strings.soilMoisture)
    }
  }

  @Test
  fun testDirectAddDevice() {
    val repo = PlantGuardianRepository()
    val manager = DirectDeviceManager(repo)
    manager.directAddDevice("ESP32-GARDEN-01", "Greenhouse West", "Sector 3")
    assertTrue(repo.devices.value.any { it.id == "ESP32-GARDEN-01" && it.name == "Greenhouse West" })
    assertEquals("ESP32-GARDEN-01", repo.selectedDeviceId.value)
  }

  @Test
  fun testSensorDataNullableNoFakeDefaults() {
    val emptySensor = SensorData()
    assertNull(emptySensor.temperatureC)
    assertNull(emptySensor.humidityPercent)
    assertNull(emptySensor.soilZone1)
    assertNull(emptySensor.lightPercent)
    assertNull(emptySensor.batteryPercent)
    assertNull(emptySensor.solarCharging)
    assertNull(emptySensor.soilAverage)
    assertEquals("--", emptySensor.lightLevelLabel)

    val validLightSensor = SensorData(lightPercent = 75)
    assertEquals("Bright", validLightSensor.lightLevelLabel)
    val dimSensor = SensorData(lightPercent = 40)
    assertEquals("Dim", dimSensor.lightLevelLabel)
    val darkSensor = SensorData(lightPercent = 15)
    assertEquals("Dark", darkSensor.lightLevelLabel)
  }

  @Test
  fun testTelemetryPointSafeFallbacks() {
    val partialPoint = TelemetryPoint(
      timestampMs = 123456789L,
      tempC = null,
      humidity = null,
      soilAvg = null,
      lightPercent = null,
      batteryPercent = null
    )
    assertTrue("Safe temp should be non-null positive", partialPoint.safeTempC > 0)
    assertTrue("Safe humidity should be non-null positive", partialPoint.safeHumidity > 0)
    assertTrue("Safe soil average should be positive", partialPoint.safeSoilAvg > 0)
    assertTrue("Safe light should be non-negative", partialPoint.safeLightPercent >= 0)
    assertTrue("Safe battery should be non-negative", partialPoint.safeBatteryPercent >= 0)
  }

  @Test
  fun testPlantHealthEvaluation() {
    val healthySensor = SensorData(
      temperatureC = 24.5,
      humidityPercent = 62.0,
      soilZone1 = 60,
      soilZone2 = 58,
      soilZone3 = 64,
      lightPercent = 70,
      isRaining = false,
      batteryPercent = 90,
      solarCharging = true,
      lastSeenEpochMs = System.currentTimeMillis()
    )

    val health = PlantHealthAnalysis.evaluate(healthySensor, isNodePoweredOn = true)
    assertTrue("Overall score should be high for optimal sensors", health.overallScore >= 85)
    assertEquals(PlantHealthTier.THRIVING, health.tier)
    assertFalse("Healthy plants do not require immediate relay watering", health.requiresRelayWatering)

    val drySensor = healthySensor.copy(
      soilZone1 = 20,
      soilZone2 = 18,
      soilZone3 = 24
    )
    val dryHealth = PlantHealthAnalysis.evaluate(drySensor, isNodePoweredOn = true)
    assertTrue("Dry soil should trigger relay watering requirement", dryHealth.requiresRelayWatering)
  }
}
