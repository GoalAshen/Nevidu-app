package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smart.plant.guardian.data.model.PlantHealthAnalysis
import com.smart.plant.guardian.data.model.PlantHealthTier

@Composable
fun PlantHealthCard(
  plantHealth: PlantHealthAnalysis,
  isRelayOn: Boolean,
  canControl: Boolean,
  onToggleRelay: (Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  val tierColor = when (plantHealth.tier) {
    PlantHealthTier.THRIVING -> MaterialTheme.colorScheme.primary
    PlantHealthTier.HEALTHY -> MaterialTheme.colorScheme.tertiary
    PlantHealthTier.ATTENTION_NEEDED -> MaterialTheme.colorScheme.secondary
    PlantHealthTier.STRESSED -> MaterialTheme.colorScheme.error
  }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("plant_health_card"),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = tierColor.copy(alpha = 0.2f),
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.Eco,
                contentDescription = null,
                tint = tierColor,
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Column {
            Text(
              text = "Plant Vitality Assessment",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = plantHealth.vitalitySummary,
              style = MaterialTheme.typography.bodySmall,
              color = tierColor,
              fontWeight = FontWeight.Bold
            )
          }
        }

        // Score Badge
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = tierColor.copy(alpha = 0.15f),
          border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(tierColor))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Text(
              text = "${plantHealth.overallScore}",
              fontSize = 18.sp,
              fontWeight = FontWeight.Black,
              color = tierColor
            )
            Text(
              text = "/100",
              fontSize = 11.sp,
              color = tierColor.copy(alpha = 0.8f)
            )
          }
        }
      }

      Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          plantHealth.primaryIssue?.let { issue ->
            Text(
              text = "• $issue",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.error
            )
          }
          Text(
            text = plantHealth.recommendation,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 17.sp
          )
        }
      }

      // Quick Water Action (hidden or disabled if viewer cannot control)
      if (canControl && plantHealth.requiresRelayWatering) {
        Button(
          onClick = { onToggleRelay(!isRelayOn) },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isRelayOn) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
          ),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().testTag("quick_water_action_button")
        ) {
          Icon(imageVector = Icons.Default.WaterDrop, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isRelayOn) "Stop Irrigation Pump" else "Initiate Quick Watering Pulse",
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
