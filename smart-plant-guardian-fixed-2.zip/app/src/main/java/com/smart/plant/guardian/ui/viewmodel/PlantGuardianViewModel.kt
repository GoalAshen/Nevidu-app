package com.smart.plant.guardian.ui.viewmodel

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.smart.plant.guardian.data.model.*
import com.smart.plant.guardian.data.remote.FirebaseSettings
import com.smart.plant.guardian.data.repository.PlantGuardianRepository
import com.smart.plant.guardian.localization.PlantGuardianTranslations
import com.smart.plant.guardian.localization.PlantLanguage
import com.smart.plant.guardian.localization.TranslationStrings
import com.smart.plant.guardian.pairing.DirectDeviceManager
import com.smart.plant.guardian.ui.theme.ThemeModePreference
import com.smart.plant.guardian.ui.theme.ThemePalettePreference
import kotlinx.coroutines.flow.*

class PlantGuardianViewModel(
  val repository: PlantGuardianRepository = PlantGuardianRepository()
) : ViewModel() {

  val deviceManager = DirectDeviceManager(repository)

  // Localization States
  private val _currentLanguage = MutableStateFlow(PlantLanguage.ENGLISH)
  val currentLanguage: StateFlow<PlantLanguage> = _currentLanguage.asStateFlow()

  val translationStrings: StateFlow<TranslationStrings> = _currentLanguage.map {
    PlantGuardianTranslations.get(it)
  }.stateIn(viewModelScope, SharingStarted.Eagerly, PlantGuardianTranslations.get(PlantLanguage.ENGLISH))

  private val _showWelcomeLanguageModal = MutableStateFlow(false)
  val showWelcomeLanguageModal: StateFlow<Boolean> = _showWelcomeLanguageModal.asStateFlow()

  // Theme Settings
  private val _themeMode = MutableStateFlow(ThemeModePreference.SYSTEM)
  val themeMode: StateFlow<ThemeModePreference> = _themeMode.asStateFlow()

  private val _themePalette = MutableStateFlow(ThemePalettePreference.WALLPAPER)
  val themePalette: StateFlow<ThemePalettePreference> = _themePalette.asStateFlow()

  // User Profile & Roles
  val currentUserProfile: StateFlow<UserProfile?> = repository.currentUserProfile
  val allUsers: StateFlow<List<UserProfile>> = repository.allUsers
  val auditLogs: StateFlow<List<AuditEntry>> = repository.auditLogs

  val isAdmin: StateFlow<Boolean> = currentUserProfile.map { it?.role == UserRole.ADMIN }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val isOperator: StateFlow<Boolean> = currentUserProfile.map { it?.role == UserRole.ADMIN || it?.role == UserRole.OPERATOR }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val isViewer: StateFlow<Boolean> = currentUserProfile.map { it?.role == UserRole.VIEWER }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

  val isPending: StateFlow<Boolean> = currentUserProfile.map { it?.status == UserStatus.PENDING }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

  val isBlocked: StateFlow<Boolean> = currentUserProfile.map { it?.status == UserStatus.BLOCKED }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

  // Core Repository States
  val firebaseConfig: StateFlow<FirebaseSettings> = repository.firebaseConfig
  val connectionError: StateFlow<String?> = repository.connectionError
  val commandFeedbackError: StateFlow<String?> = repository.commandFeedbackError
  val allDevices: StateFlow<List<Device>> = repository.devices
  val selectedDeviceId: StateFlow<String> = repository.selectedDeviceId
  val alerts: StateFlow<List<SystemAlert>> = repository.alerts
  val systemNotificationsEnabled: StateFlow<Boolean> = repository.systemNotificationsEnabled

  val selectedDevice: StateFlow<Device?> = combine(
    repository.devices,
    repository.selectedDeviceId
  ) { devices, id ->
    devices.find { it.id == id } ?: devices.firstOrNull()
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val currentSensorData: StateFlow<SensorData?> = combine(
    repository.sensorDataMap,
    repository.selectedDeviceId
  ) { map, id ->
    map[id]
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val currentRelayState: StateFlow<RelayState?> = combine(
    repository.relayStateMap,
    repository.selectedDeviceId
  ) { map, id ->
    map[id]
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val currentThresholds: StateFlow<EcoThresholds?> = combine(
    repository.thresholdsMap,
    repository.selectedDeviceId
  ) { map, id ->
    map[id]
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val currentHardwareControls: StateFlow<HardwareControls?> = combine(
    repository.hardwareControlsMap,
    repository.selectedDeviceId
  ) { map, id ->
    map[id]
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val currentSchedule: StateFlow<DailySchedule?> = combine(
    repository.scheduleMap,
    repository.selectedDeviceId
  ) { map, id ->
    map[id]
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val currentHistory: StateFlow<List<TelemetryPoint>> = combine(
    repository.telemetryHistoryMap,
    repository.selectedDeviceId
  ) { map, id ->
    map[id] ?: emptyList()
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val isCurrentDeviceOnline: StateFlow<Boolean> = combine(
    currentSensorData,
    repository.firebaseConfig
  ) { sensor, _ ->
    sensor?.isOnline(repository.getSynchronizedServerTime()) ?: false
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val currentPlantHealth: StateFlow<PlantHealthAnalysis> = combine(
    currentSensorData,
    selectedDevice,
    currentThresholds
  ) { sensor, device, thresh ->
    PlantHealthAnalysis.evaluate(
      sensorData = sensor,
      thresholds = thresh ?: EcoThresholds(),
      isNodePoweredOn = device?.isPoweredOn ?: true
    )
  }.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    PlantHealthAnalysis.evaluate(null)
  )

  fun setLanguage(language: PlantLanguage) {
    _currentLanguage.value = language
  }

  fun showLanguagePicker() {
    _showWelcomeLanguageModal.value = true
  }

  fun dismissWelcomeLanguageModal() {
    _showWelcomeLanguageModal.value = false
  }

  fun setThemeMode(mode: ThemeModePreference) {
    _themeMode.value = mode
  }

  fun setThemePalette(palette: ThemePalettePreference) {
    _themePalette.value = palette
  }

  // Device & Telemetry Actions
  fun selectDevice(deviceId: String) {
    repository.selectDevice(deviceId)
  }

  fun togglePump(turnOn: Boolean, context: Context? = null) {
    val devId = selectedDeviceId.value
    repository.togglePump(devId, turnOn)
    vibrate(context, 40)
  }

  fun setRelayMode(mode: RelayMode, context: Context? = null) {
    val devId = selectedDeviceId.value
    repository.setRelayMode(devId, mode)
    vibrate(context, 30)
  }

  fun toggleDevicePower(powerOn: Boolean, context: Context? = null) {
    val devId = selectedDeviceId.value
    repository.toggleDevicePower(devId, powerOn)
    vibrate(context, 50)
  }

  fun toggleBuzzer(active: Boolean, context: Context? = null) {
    val devId = selectedDeviceId.value
    repository.toggleBuzzer(devId, active)
    vibrate(context, 35)
  }

  fun toggleSpeaker(active: Boolean, context: Context? = null) {
    val devId = selectedDeviceId.value
    repository.toggleSpeaker(devId, active)
    vibrate(context, 60)
  }

  fun toggleLed(color: String, turnOn: Boolean, context: Context? = null) {
    val devId = selectedDeviceId.value
    repository.toggleLed(devId, color, turnOn)
    vibrate(context, 20)
  }

  fun updateThresholds(thresholds: EcoThresholds) {
    val devId = selectedDeviceId.value
    repository.updateThresholds(devId, thresholds)
  }

  fun updateSchedule(schedule: DailySchedule) {
    val devId = selectedDeviceId.value
    repository.updateDailySchedule(devId, schedule)
  }

  fun toggleRainSensor(context: Context? = null) {
    val devId = selectedDeviceId.value
    repository.toggleRainSensor(devId)
    vibrate(context, 30)
  }

  fun addDevice(id: String, name: String, location: String, lat: Double = 37.7749, lng: Double = -122.4194) {
    repository.addDevice(id = id, name = name, location = location, lat = lat, lng = lng)
  }

  fun removeDevice(deviceId: String) {
    repository.removeDevice(deviceId)
  }

  fun updateDeviceLocation(deviceId: String, lat: Double, lng: Double, location: String) {
    repository.updateDeviceLocation(deviceId, lat, lng, location)
  }

  // Admin Actions
  fun approveUser(uid: String, context: Context? = null) {
    repository.approveUser(uid)
    context?.let { Toast.makeText(it, "User approved", Toast.LENGTH_SHORT).show() }
  }

  fun updateUserRole(uid: String, newRole: UserRole, context: Context? = null) {
    repository.updateUserRole(uid, newRole)
    context?.let { Toast.makeText(it, "User role set to ${newRole.roleName}", Toast.LENGTH_SHORT).show() }
  }

  fun updateUserStatus(uid: String, newStatus: UserStatus, context: Context? = null) {
    repository.updateUserStatus(uid, newStatus)
    context?.let { Toast.makeText(it, "User status set to ${newStatus.statusName}", Toast.LENGTH_SHORT).show() }
  }

  fun assignDeviceMember(deviceId: String, uid: String, grantAccess: Boolean, context: Context? = null) {
    repository.assignDeviceMember(deviceId, uid, grantAccess)
    context?.let { Toast.makeText(it, "Device access updated", Toast.LENGTH_SHORT).show() }
  }

  fun applyGlobalThresholds(thresholds: EcoThresholds, context: Context? = null) {
    repository.applyGlobalThresholdsToAllDevices(thresholds)
    context?.let { Toast.makeText(it, "Global thresholds applied to all devices", Toast.LENGTH_SHORT).show() }
  }

  fun emergencyTurnAllPumpsOff(context: Context? = null) {
    repository.emergencyTurnAllPumpsOff()
    vibrate(context, 100)
    context?.let { Toast.makeText(it, "EMERGENCY: All pumps stopped", Toast.LENGTH_LONG).show() }
  }

  fun emergencyForceManualModeAll(context: Context? = null) {
    repository.emergencyForceManualModeAll()
    vibrate(context, 80)
    context?.let { Toast.makeText(it, "EMERGENCY: All devices set to MANUAL", Toast.LENGTH_LONG).show() }
  }

  // Auth Operations
  fun registerAccount(email: String, pass: String, displayName: String, onResult: (Boolean, String?) -> Unit) {
    repository.registerAccount(email, pass, displayName, onResult)
  }

  fun signIn(email: String, pass: String, onResult: (Boolean, String?) -> Unit) {
    repository.signIn(email, pass, onResult)
  }

  fun signOut() {
    repository.signOut()
  }

  fun refreshProfile() {
    repository.refreshUserProfile()
  }

  fun saveFirebaseSettings(settings: FirebaseSettings, context: Context? = null) {
    repository.updateFirebaseConfig(settings)
    context?.let { Toast.makeText(it, "Firebase configuration saved", Toast.LENGTH_SHORT).show() }
  }

  fun dismissConnectionError() {
    repository.dismissConnectionError()
  }

  fun dismissCommandFeedbackError() {
    repository.dismissCommandFeedbackError()
  }

  fun setAppContext(context: Context) {
    repository.setApplicationContext(context)
  }

  fun dismissAlert(alertId: String) {
    repository.dismissAlert(alertId)
  }

  fun clearEventLogs(context: Context? = null) {
    repository.clearEventLogs()
    context?.let { Toast.makeText(it, "Alert logs cleared", Toast.LENGTH_SHORT).show() }
  }

  fun toggleSystemNotifications(enabled: Boolean, context: Context? = null) {
    repository.toggleSystemNotifications(enabled)
    context?.let {
      Toast.makeText(it, if (enabled) "Notifications active" else "Notifications muted", Toast.LENGTH_SHORT).show()
    }
  }

  fun triggerTestNotification(context: Context) {
    com.smart.plant.guardian.util.NotificationHelper.sendTestNotification(context)
    vibrate(context, 60)
  }

  private fun vibrate(context: Context?, durationMs: Long) {
    if (context == null) return
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
      } else {
        @Suppress("DEPRECATION")
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        @Suppress("DEPRECATION")
        vibrator?.vibrate(durationMs)
      }
    } catch (_: Exception) {}
  }
}
