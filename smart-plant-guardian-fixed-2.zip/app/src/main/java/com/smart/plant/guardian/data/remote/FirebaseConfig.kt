package com.smart.plant.guardian.data.remote

import android.content.Context
import android.content.SharedPreferences

data class FirebaseSettings(
  val appId: String = "", // Format: 1:123456789:android:abcdef
  val apiKey: String = "",
  val databaseUrl: String = "",
  val projectId: String = "",
  val ownerEmail: String = "",
  val authPassword: String = ""
) {
  companion object {
    const val PATH_SENSORS = "/devices/{id}/sensors"
    const val PATH_STATUS = "/devices/{id}/status"
    const val PATH_COMMANDS = "/devices/{id}/commands"
    const val PATH_SETTINGS = "/devices/{id}/settings"
    const val PATH_HISTORY = "/devices/{id}/history"
  }

  fun getSensorsUrl(deviceId: String): String =
    cleanUrl("/devices/$deviceId/sensors.json")

  fun getStatusUrl(deviceId: String): String =
    cleanUrl("/devices/$deviceId/status.json")

  fun getCommandsUrl(deviceId: String): String =
    cleanUrl("/devices/$deviceId/commands.json")

  fun getSettingsUrl(deviceId: String): String =
    cleanUrl("/devices/$deviceId/settings.json")

  fun getHistoryUrl(deviceId: String): String =
    cleanUrl("/devices/$deviceId/history.json")

  fun getUsersUrl(): String =
    cleanUrl("/users.json")

  fun getAuditUrl(): String =
    cleanUrl("/audit.json")

  private fun cleanUrl(path: String): String {
    val base = databaseUrl.trim().removeSuffix("/")
    val p = if (path.startsWith("/")) path else "/$path"
    return "$base$p"
  }
}

object FirebasePrefs {
  private const val PREFS_NAME = "smart_plant_guardian_prefs"
  private const val KEY_APP_ID = "app_id"
  private const val KEY_API_KEY = "api_key"
  private const val KEY_DB_URL = "database_url"
  private const val KEY_PROJECT_ID = "project_id"
  private const val KEY_OWNER_EMAIL = "owner_email"
  private const val KEY_AUTH_PASSWORD = "auth_password"

  fun load(context: Context): FirebaseSettings {
    val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return FirebaseSettings(
      appId = prefs.getString(KEY_APP_ID, "") ?: "",
      apiKey = prefs.getString(KEY_API_KEY, "") ?: "",
      databaseUrl = prefs.getString(KEY_DB_URL, "") ?: "",
      projectId = prefs.getString(KEY_PROJECT_ID, "") ?: "",
      ownerEmail = prefs.getString(KEY_OWNER_EMAIL, "") ?: "",
      authPassword = prefs.getString(KEY_AUTH_PASSWORD, "") ?: ""
    )
  }

  fun save(context: Context, settings: FirebaseSettings) {
    val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit()
      .putString(KEY_APP_ID, settings.appId)
      .putString(KEY_API_KEY, settings.apiKey)
      .putString(KEY_DB_URL, settings.databaseUrl)
      .putString(KEY_PROJECT_ID, settings.projectId)
      .putString(KEY_OWNER_EMAIL, settings.ownerEmail)
      .putString(KEY_AUTH_PASSWORD, settings.authPassword)
      .apply()
  }
}
