package com.smart.plant.guardian.ui.auth

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.smart.plant.guardian.data.remote.FirebaseSettings
import com.smart.plant.guardian.ui.components.FirebaseConfigCard
import com.smart.plant.guardian.ui.components.PlantGuardianLogo

/**
 * Full-screen gate shown until the user is signed in.
 * Step 1: enter Firebase settings. Step 2: sign in or register.
 */
@Composable
fun SignInGate(
  config: FirebaseSettings,
  connectionError: String?,
  onSaveConfig: (FirebaseSettings) -> Unit,
  onSignIn: (email: String, pass: String, onResult: (Boolean, String?) -> Unit) -> Unit,
  onRegister: (email: String, pass: String, displayName: String, onResult: (Boolean, String?) -> Unit) -> Unit,
  onDismissError: () -> Unit
) {
  var showAuth by remember { mutableStateOf(false) }
  val isConfigured = config.databaseUrl.isNotBlank() &&
    config.apiKey.isNotBlank() &&
    config.appId.isNotBlank()

  Surface(
    modifier = Modifier.fillMaxSize(),
    color = MaterialTheme.colorScheme.background
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      PlantGuardianLogo(modifier = Modifier.size(88.dp))

      Text(
        text = "Smart Plant Guardian",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.ExtraBold,
        textAlign = TextAlign.Center
      )

      Text(
        text = if (isConfigured) {
          "Sign in to monitor and control your plants."
        } else {
          "Step 1: enter your Firebase settings below and save. Step 2: sign in."
        },
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
      )

      if (connectionError != null) {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = MaterialTheme.colorScheme.errorContainer,
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = connectionError,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onErrorContainer,
              modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onDismissError) {
              Text("OK")
            }
          }
        }
      }

      FirebaseConfigCard(
        config = config,
        onSaveConfig = onSaveConfig
      )

      Button(
        onClick = { showAuth = true },
        enabled = isConfigured,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("gate_sign_in_button")
      ) {
        Text(
          text = "Sign in or register",
          fontWeight = FontWeight.Bold
        )
      }
    }
  }

  AuthModalDialog(
    isOpen = showAuth,
    onDismiss = { showAuth = false },
    onSignIn = onSignIn,
    onRegister = onRegister
  )
}
