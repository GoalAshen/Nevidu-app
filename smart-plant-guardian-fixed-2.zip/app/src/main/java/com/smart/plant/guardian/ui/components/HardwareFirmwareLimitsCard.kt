package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smart.plant.guardian.data.model.HardwareControls

@Composable
fun HardwareFirmwareLimitsCard(
  hardwareControls: HardwareControls?,
  canControl: Boolean,
  onToggleBuzzer: (Boolean) -> Unit,
  onToggleSpeaker: (Boolean) -> Unit,
  onToggleLed: (color: String, turnOn: Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  val controls = hardwareControls ?: HardwareControls()

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("hardware_firmware_limits_card"),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.secondaryContainer,
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.Memory,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Column {
            Text(
              text = "Hardware Signals & Alarms",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Onboard audio transducers & status LEDs",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      // Audio Alarms: Buzzer & Speaker
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Buzzer Button
        OutlinedButton(
          onClick = { if (canControl) onToggleBuzzer(!controls.buzzerActive) },
          enabled = canControl,
          colors = if (controls.buzzerActive) ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.errorContainer) else ButtonDefaults.outlinedButtonColors(),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f).testTag("toggle_buzzer_button")
        ) {
          Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (controls.buzzerActive) "Buzzer ON" else "Buzzer OFF", fontSize = 11.sp)
        }

        // Speaker Siren Button
        OutlinedButton(
          onClick = { if (canControl) onToggleSpeaker(!controls.speakerAlertActive) },
          enabled = canControl,
          colors = if (controls.speakerAlertActive) ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.errorContainer) else ButtonDefaults.outlinedButtonColors(),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f).testTag("toggle_speaker_button")
        ) {
          Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (controls.speakerAlertActive) "Siren ON" else "Siren OFF", fontSize = 11.sp)
        }
      }

      // Diagnostic LEDs
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Diagnostic LEDs (RGBY):", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          FilterChip(
            selected = controls.ledRed,
            onClick = { if (canControl) onToggleLed("red", !controls.ledRed) },
            enabled = canControl,
            label = { Text("Red") },
            modifier = Modifier.weight(1f).testTag("led_red_chip")
          )
          FilterChip(
            selected = controls.ledBlue,
            onClick = { if (canControl) onToggleLed("blue", !controls.ledBlue) },
            enabled = canControl,
            label = { Text("Blue") },
            modifier = Modifier.weight(1f).testTag("led_blue_chip")
          )
          FilterChip(
            selected = controls.ledGreen,
            onClick = { if (canControl) onToggleLed("green", !controls.ledGreen) },
            enabled = canControl,
            label = { Text("Green") },
            modifier = Modifier.weight(1f).testTag("led_green_chip")
          )
          FilterChip(
            selected = controls.ledYellow,
            onClick = { if (canControl) onToggleLed("yellow", !controls.ledYellow) },
            enabled = canControl,
            label = { Text("Yellow") },
            modifier = Modifier.weight(1f).testTag("led_yellow_chip")
          )
        }
      }
    }
  }
}
