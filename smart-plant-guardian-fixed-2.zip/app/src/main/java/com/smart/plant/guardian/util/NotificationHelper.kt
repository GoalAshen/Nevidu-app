package com.smart.plant.guardian.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.smart.plant.guardian.data.model.AlertType

object NotificationHelper {
  const val CHANNEL_ID = "smart_plant_guardian_alerts"
  const val CHANNEL_NAME = "Smart Plant Guardian Alerts"
  const val CHANNEL_DESC = "Real-time critical plant vitality, irrigation, and device status alerts"

  fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val importance = NotificationManager.IMPORTANCE_HIGH
      val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
        description = CHANNEL_DESC
        enableVibration(true)
        enableLights(true)
      }
      val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
      notificationManager?.createNotificationChannel(channel)
    }
  }

  fun sendAlertNotification(
    context: Context,
    id: Int,
    title: String,
    message: String,
    alertType: AlertType
  ) {
    try {
      createNotificationChannel(context)
      val iconRes = when (alertType) {
        AlertType.DRY_SOIL -> android.R.drawable.ic_dialog_alert
        AlertType.HIGH_TEMP -> android.R.drawable.ic_dialog_alert
        AlertType.RAIN -> android.R.drawable.ic_dialog_info
        AlertType.LOW_BATTERY -> android.R.drawable.ic_lock_idle_low_battery
        AlertType.DEVICE_OFFLINE -> android.R.drawable.stat_notify_error
        AlertType.SYSTEM_INFO -> android.R.drawable.ic_dialog_info
      }

      val builder = NotificationCompat.Builder(context, CHANNEL_ID)
        .setSmallIcon(iconRes)
        .setContentTitle(title)
        .setContentText(message)
        .setStyle(NotificationCompat.BigTextStyle().bigText(message))
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setAutoCancel(true)

      val manager = NotificationManagerCompat.from(context)
      manager.notify(id, builder.build())
    } catch (_: SecurityException) {
      // Missing POST_NOTIFICATIONS permission
    } catch (_: Exception) {}
  }

  fun sendTestNotification(context: Context) {
    sendAlertNotification(
      context = context,
      id = 9999,
      title = "Smart Plant Guardian System Test",
      message = "All telemetry notification channels and alert triggers are functional.",
      alertType = AlertType.SYSTEM_INFO
    )
  }
}
