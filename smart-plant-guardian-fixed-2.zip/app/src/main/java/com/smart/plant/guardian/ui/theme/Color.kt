package com.smart.plant.guardian.ui.theme

import androidx.compose.ui.graphics.Color

// Fixed Nature Green / Aqua Palette (Android 11 & fallback / user preference)
val ForestGreenPrimary = Color(0xFF1B6A4C)
val ForestGreenOnPrimary = Color(0xFFFFFFFF)
val ForestGreenPrimaryContainer = Color(0xFFA6F2CA)
val ForestGreenOnPrimaryContainer = Color(0xFF002114)

val AquaSecondary = Color(0xFF006876)
val AquaOnSecondary = Color(0xFFFFFFFF)
val AquaSecondaryContainer = Color(0xFFA1EFFF)
val AquaOnSecondaryContainer = Color(0xFF001F25)

val PlantTertiary = Color(0xFF00677E)
val PlantOnTertiary = Color(0xFFFFFFFF)
val PlantTertiaryContainer = Color(0xFFB5EBFF)
val PlantOnTertiaryContainer = Color(0xFF001F28)

// Dark Theme Variants
val DarkForestGreenPrimary = Color(0xFF8AD5AF)
val DarkForestGreenOnPrimary = Color(0xFF003823)
val DarkForestGreenPrimaryContainer = Color(0xFF005234)
val DarkForestGreenOnPrimaryContainer = Color(0xFFA6F2CA)

val DarkAquaSecondary = Color(0xFF82D3E3)
val DarkAquaOnSecondary = Color(0xFF00363E)
val DarkAquaSecondaryContainer = Color(0xFF004E59)
val DarkAquaOnSecondaryContainer = Color(0xFFA1EFFF)

val DarkPlantTertiary = Color(0xFF86D1EA)
val DarkPlantOnTertiary = Color(0xFF003542)
val DarkPlantTertiaryContainer = Color(0xFF004D5F)
val DarkPlantOnTertiaryContainer = Color(0xFFB5EBFF)

// Status Colors
val StatusDryError = Color(0xFFBA1A1A)
val StatusDryErrorContainer = Color(0xFFFFDAD6)
val StatusDryOnError = Color(0xFFFFFFFF)

val DarkStatusDryError = Color(0xFFFFB4AB)
val DarkStatusDryErrorContainer = Color(0xFF93000A)

// Harmonized Warning Gold / Amber
val StatusWarningAmber = Color(0xFFC05600)
val DarkStatusWarningAmber = Color(0xFFFFB68E)
