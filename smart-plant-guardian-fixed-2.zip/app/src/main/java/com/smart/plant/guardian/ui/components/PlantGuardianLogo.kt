package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun PlantGuardianLogo(
  modifier: Modifier = Modifier.size(36.dp),
  shieldBgColor: Color = Color(0xFF0B3D2E),
  plantColor: Color = Color(0xFF3DDC84),
  waterColor: Color = Color(0xFF4FC3F7)
) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height

    // 1. Draw rounded shield
    val shieldPath = Path().apply {
      moveTo(w * 0.5f, h * 0.12f)
      cubicTo(w * 0.7f, h * 0.12f, w * 0.85f, h * 0.16f, w * 0.85f, h * 0.16f)
      cubicTo(w * 0.85f, h * 0.55f, w * 0.7f, h * 0.78f, w * 0.5f, h * 0.90f)
      cubicTo(w * 0.3f, h * 0.78f, w * 0.15f, h * 0.55f, w * 0.15f, h * 0.16f)
      cubicTo(w * 0.15f, h * 0.16f, w * 0.3f, h * 0.12f, w * 0.5f, h * 0.12f)
      close()
    }
    drawPath(shieldPath, color = shieldBgColor)
    drawPath(
      shieldPath,
      color = plantColor,
      style = Stroke(width = w * 0.05f, join = StrokeJoin.Round)
    )

    // 2. Sprouting stem
    val stemPath = Path().apply {
      moveTo(w * 0.48f, h * 0.75f)
      cubicTo(w * 0.48f, h * 0.58f, w * 0.50f, h * 0.45f, w * 0.50f, h * 0.32f)
    }
    drawPath(
      stemPath,
      color = plantColor,
      style = Stroke(width = w * 0.06f, cap = StrokeCap.Round)
    )

    // 3. Left Leaf
    val leftLeaf = Path().apply {
      moveTo(w * 0.49f, h * 0.55f)
      cubicTo(w * 0.36f, h * 0.54f, w * 0.30f, h * 0.42f, w * 0.34f, h * 0.35f)
      cubicTo(w * 0.43f, h * 0.33f, w * 0.49f, h * 0.45f, w * 0.49f, h * 0.55f)
      close()
    }
    drawPath(leftLeaf, color = plantColor)

    // 4. Right Leaf
    val rightLeaf = Path().apply {
      moveTo(w * 0.50f, h * 0.46f)
      cubicTo(w * 0.62f, h * 0.44f, w * 0.68f, h * 0.34f, w * 0.64f, h * 0.28f)
      cubicTo(w * 0.54f, h * 0.28f, w * 0.49f, h * 0.38f, w * 0.50f, h * 0.46f)
      close()
    }
    drawPath(rightLeaf, color = plantColor)

    // 5. Water drop on right
    val dropPath = Path().apply {
      moveTo(w * 0.70f, h * 0.56f)
      cubicTo(w * 0.70f, h * 0.50f, w * 0.77f, h * 0.42f, w * 0.77f, h * 0.42f)
      cubicTo(w * 0.77f, h * 0.42f, w * 0.84f, h * 0.50f, w * 0.84f, h * 0.56f)
      cubicTo(w * 0.84f, h * 0.62f, w * 0.81f, h * 0.66f, w * 0.77f, h * 0.66f)
      cubicTo(w * 0.73f, h * 0.66f, w * 0.70f, h * 0.62f, w * 0.70f, h * 0.56f)
      close()
    }
    drawPath(dropPath, color = waterColor)
    drawPath(dropPath, color = Color.White.copy(alpha = 0.8f), style = Stroke(width = w * 0.02f))
  }
}
