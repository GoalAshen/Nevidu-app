package com.smart.plant.guardian

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.smart.plant.guardian.data.model.DailySchedule
import com.smart.plant.guardian.data.model.UserRole
import com.smart.plant.guardian.localization.TranslationStrings
import com.smart.plant.guardian.ui.admin.AdminPanelDialog
import com.smart.plant.guardian.ui.auth.AuthModalDialog
import com.smart.plant.guardian.ui.auth.BlockedUserNotice
import com.smart.plant.guardian.ui.auth.PendingApprovalNotice
import com.smart.plant.guardian.ui.auth.SignInGate
import com.smart.plant.guardian.ui.components.*
import com.smart.plant.guardian.ui.theme.SmartPlantGuardianTheme
import com.smart.plant.guardian.ui.theme.ThemeModePreference
import com.smart.plant.guardian.ui.theme.ThemePalettePreference
import com.smart.plant.guardian.ui.viewmodel.PlantGuardianViewModel
import com.smart.plant.guardian.util.NotificationHelper

enum class PlantTab(val icon: androidx.compose.ui.graphics.vector.ImageVector) {
  DASHBOARD(Icons.Default.Dashboard),
  CONTROLS(Icons.Default.Tune),
  CHARTS(Icons.Default.ShowChart),
  PAIR_NODE(Icons.Default.AddCircleOutline),
  SETTINGS(Icons.Default.Settings);

  fun getLabel(strings: TranslationStrings): String = when (this) {
    DASHBOARD -> strings.navDashboard
    CONTROLS -> strings.navControls
    CHARTS -> strings.navCharts
    PAIR_NODE -> strings.navAddDevice
    SETTINGS -> strings.navSettings
  }
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    NotificationHelper.createNotificationChannel(this)

    setContent {
      val viewModel: PlantGuardianViewModel = viewModel()
      val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
      val themePalette by viewModel.themePalette.collectAsStateWithLifecycle()

      SmartPlantGuardianTheme(
        themeMode = themeMode,
        themePalette = themePalette
      ) {
        PlantGuardianApp(viewModel = viewModel)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlantGuardianApp(
  viewModel: PlantGuardianViewModel
) {
  val context = LocalContext.current
  var currentTab by remember { mutableStateOf(PlantTab.DASHBOARD) }
  var showDeviceSwitcherModal by remember { mutableStateOf(false) }
  var showAuthModal by remember { mutableStateOf(false) }
  var showAdminPanel by remember { mutableStateOf(false) }
  var showThemeDialog by remember { mutableStateOf(false) }

  // Localization States
  val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
  val strings by viewModel.translationStrings.collectAsStateWithLifecycle()
  val showWelcomeModal by viewModel.showWelcomeLanguageModal.collectAsStateWithLifecycle()

  // User Profile & Roles
  val currentUserProfile by viewModel.currentUserProfile.collectAsStateWithLifecycle()
  val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
  val isOperator by viewModel.isOperator.collectAsStateWithLifecycle()
  val isPending by viewModel.isPending.collectAsStateWithLifecycle()
  val isBlocked by viewModel.isBlocked.collectAsStateWithLifecycle()
  val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
  val themePalette by viewModel.themePalette.collectAsStateWithLifecycle()

  // Telemetry & Control States
  val selectedDevice by viewModel.selectedDevice.collectAsStateWithLifecycle()
  val allDevices by viewModel.allDevices.collectAsStateWithLifecycle()
  val sensorData by viewModel.currentSensorData.collectAsStateWithLifecycle()
  val plantHealth by viewModel.currentPlantHealth.collectAsStateWithLifecycle()
  val relayState by viewModel.currentRelayState.collectAsStateWithLifecycle()
  val thresholds by viewModel.currentThresholds.collectAsStateWithLifecycle()
  val hardwareControls by viewModel.currentHardwareControls.collectAsStateWithLifecycle()
  val schedule by viewModel.currentSchedule.collectAsStateWithLifecycle()
  val history by viewModel.currentHistory.collectAsStateWithLifecycle()
  val alerts by viewModel.alerts.collectAsStateWithLifecycle()
  val firebaseConfig by viewModel.firebaseConfig.collectAsStateWithLifecycle()
  val connectionError by viewModel.connectionError.collectAsStateWithLifecycle()
  val commandFeedbackError by viewModel.commandFeedbackError.collectAsStateWithLifecycle()
  val isOnline by viewModel.isCurrentDeviceOnline.collectAsStateWithLifecycle()
  val notificationsEnabled by viewModel.systemNotificationsEnabled.collectAsStateWithLifecycle()

  // Notification runtime permission launcher (Android 13+ / API 33+)
  val notificationPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    if (isGranted) {
      NotificationHelper.sendTestNotification(context)
    }
  }

  LaunchedEffect(Unit) {
    viewModel.setAppContext(context.applicationContext)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
  }

  val listState = rememberLazyListState()

  // Role Gate: Pending Approval
  if (isPending && currentUserProfile != null) {
    Box(
      modifier = Modifier.fillMaxSize().padding(16.dp),
      contentAlignment = Alignment.Center
    ) {
      PendingApprovalNotice(
        userProfile = currentUserProfile!!,
        onSignOut = { viewModel.signOut() },
        onRefresh = { viewModel.refreshProfile() }
      )
    }
    return
  }

  // Role Gate: Blocked User
  if (isBlocked && currentUserProfile != null) {
    Box(
      modifier = Modifier.fillMaxSize().padding(16.dp),
      contentAlignment = Alignment.Center
    ) {
      BlockedUserNotice(
        userProfile = currentUserProfile!!,
        onSignOut = { viewModel.signOut() }
      )
    }
    return
  }

  // Gate: sign-in is required (no guest or demo access)
  if (currentUserProfile == null) {
    SignInGate(
      config = firebaseConfig,
      connectionError = connectionError,
      onSaveConfig = { viewModel.saveFirebaseSettings(it, context) },
      onSignIn = { email, pass, onResult -> viewModel.signIn(email, pass, onResult) },
      onRegister = { email, pass, displayName, onResult -> viewModel.registerAccount(email, pass, displayName, onResult) },
      onDismissError = { viewModel.dismissConnectionError() }
    )
    return
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            PlantGuardianLogo(modifier = Modifier.size(36.dp))
            Column {
              Text(
                text = "Smart Plant Guardian",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-0.5).sp
              )
              Text(
                text = strings.appSubtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        },
        actions = {
          // Admin Panel Button (Gated to Admin only)
          if (isAdmin) {
            IconButton(
              onClick = { showAdminPanel = true },
              modifier = Modifier.testTag("top_bar_admin_button")
            ) {
              Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = "Admin Panel",
                tint = MaterialTheme.colorScheme.primary
              )
            }
          }

          // User Profile / Role Pill
          Surface(
            onClick = { showAuthModal = true },
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.padding(end = 4.dp).testTag("top_bar_auth_pill")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
              )
              Text(
                text = currentUserProfile?.role?.roleName ?: "Guest",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }

          // Language Switcher Pill
          Surface(
            onClick = { viewModel.showLanguagePicker() },
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.padding(end = 4.dp).testTag("top_bar_language_pill")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Text(
                text = "${currentLanguage.flagEmoji} ${currentLanguage.nativeName.take(4)}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
              Icon(
                imageVector = Icons.Default.ArrowDropDown,
                contentDescription = "Language",
                modifier = Modifier.size(16.dp)
              )
            }
          }

          // Device Quick Select Pill
          Surface(
            onClick = { showDeviceSwitcherModal = true },
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.padding(end = 4.dp).testTag("top_bar_device_pill")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .background(
                    if (isOnline) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    CircleShape
                  )
              )
              Text(
                text = selectedDevice?.name?.take(8) ?: strings.navAddDevice,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
              Icon(
                imageVector = Icons.Default.ArrowDropDown,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
              )
            }
          }

          // Theme Settings Button
          IconButton(
            onClick = { showThemeDialog = true },
            modifier = Modifier.testTag("top_bar_theme_toggle")
          ) {
            Icon(
              imageVector = Icons.Default.Palette,
              contentDescription = "Theme Settings",
              tint = MaterialTheme.colorScheme.onSurface
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface
        )
      )
    },
    bottomBar = {
      NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
      ) {
        PlantTab.entries.forEach { tab ->
          val selected = currentTab == tab
          val tabLabel = tab.getLabel(strings)
          NavigationBarItem(
            selected = selected,
            onClick = { currentTab = tab },
            icon = {
              if (tab == PlantTab.SETTINGS && alerts.isNotEmpty()) {
                BadgedBox(badge = { Badge(containerColor = MaterialTheme.colorScheme.error) { Text("${alerts.size}") } }) {
                  Icon(imageVector = tab.icon, contentDescription = tabLabel)
                }
              } else {
                Icon(imageVector = tab.icon, contentDescription = tabLabel)
              }
            },
            label = {
              Text(
                text = tabLabel,
                fontSize = 10.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
              indicatorColor = MaterialTheme.colorScheme.primaryContainer,
              selectedTextColor = MaterialTheme.colorScheme.primary,
              unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
              unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("nav_item_${tab.name}")
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      LazyColumn(
        state = listState,
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // Clear Error Banner for Firebase Auth / Connection Failures
        connectionError?.let { errorMsg ->
          item {
            Surface(
              shape = RoundedCornerShape(20.dp),
              color = MaterialTheme.colorScheme.errorContainer,
              border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.error)
              ),
              modifier = Modifier.fillMaxWidth().testTag("firebase_connection_error_banner")
            ) {
              Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.CloudOff,
                    contentDescription = "Connection Error",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(24.dp)
                  )
                  Text(
                    text = "Firebase Connection or Auth Alert",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onErrorContainer
                  )
                }
                Text(
                  text = errorMsg,
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onErrorContainer,
                  lineHeight = 16.sp
                )
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.End,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  TextButton(onClick = { viewModel.dismissConnectionError() }) {
                    Text("Dismiss", color = MaterialTheme.colorScheme.onErrorContainer)
                  }
                  Spacer(modifier = Modifier.width(8.dp))
                  Button(
                    onClick = { currentTab = PlantTab.SETTINGS },
                    colors = ButtonDefaults.buttonColors(
                      containerColor = MaterialTheme.colorScheme.error,
                      contentColor = MaterialTheme.colorScheme.onError
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                  ) {
                    Text("Fix Credentials", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }
        }

        // Command Feedback Error Banner (e.g. "Device did not respond" after 10s timeout)
        commandFeedbackError?.let { cmdErr ->
          item {
            Surface(
              shape = RoundedCornerShape(20.dp),
              color = MaterialTheme.colorScheme.errorContainer,
              border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.error)
              ),
              modifier = Modifier.fillMaxWidth().testTag("command_feedback_error_banner")
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Warning,
                  contentDescription = "Command Alert",
                  tint = MaterialTheme.colorScheme.error,
                  modifier = Modifier.size(22.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "Hardware Command Alert",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onErrorContainer
                  )
                  Text(
                    text = cmdErr,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer
                  )
                }
                TextButton(onClick = { viewModel.dismissCommandFeedbackError() }) {
                  Text("Dismiss", color = MaterialTheme.colorScheme.onErrorContainer)
                }
              }
            }
          }
        }

        // Heartbeat Status Header (Shown on all main tabs except pair)
        if (currentTab != PlantTab.PAIR_NODE) {
          item {
            HeartbeatStatusHeader(
              device = selectedDevice,
              sensorData = sensorData,
              isOnline = isOnline,
              currentUser = currentUserProfile,
              onDeviceSwitchClick = { showDeviceSwitcherModal = true }
            )
          }
        }

        // Active Alert Snippet on Dashboard
        if (currentTab == PlantTab.DASHBOARD && alerts.isNotEmpty()) {
          item {
            Surface(
              onClick = { currentTab = PlantTab.SETTINGS },
              shape = RoundedCornerShape(16.dp),
              color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f),
              border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.error)
              ),
              modifier = Modifier.fillMaxWidth().testTag("dashboard_alerts_alert_banner")
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "${alerts.size} Active System Alerts",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer
                  )
                  Text(
                    text = alerts.first().title,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer
                  )
                }
                Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.error)
              }
            }
          }
        }

        when (currentTab) {
          PlantTab.DASHBOARD -> {
            // Plant Health Vitality Card (Role Gated)
            item {
              PlantHealthCard(
                plantHealth = plantHealth,
                isRelayOn = relayState?.isPumpOn == true,
                canControl = isOperator,
                onToggleRelay = { viewModel.togglePump(it, context) }
              )
            }

            // SENSORS TO DISPLAY (Read from Firebase):
            // - Temperature and humidity
            item {
              TempHumidityCard(
                tempC = sensorData?.temperatureC,
                humidity = sensorData?.humidityPercent
              )
            }

            // - 3 soil moisture zones as gauges with %
            item {
              SoilMoistureGaugesCard(
                zone1 = sensorData?.soilZone1,
                zone2 = sensorData?.soilZone2,
                zone3 = sensorData?.soilZone3,
                dryThreshold = thresholds?.soilDryPercent ?: 35
              )
            }

            // - Light level & Rain: Dry / Raining
            item {
              LightAndRainCard(
                lightLux = sensorData?.lightLux,
                lightPercent = sensorData?.lightPercent,
                isRaining = sensorData?.isRaining,
                onToggleRain = { viewModel.toggleRainSensor(context) }
              )
            }

            // - Battery % and optional solar charging status
            item {
              PowerSystemCard(
                batteryPercent = sensorData?.batteryPercent,
                solarCharging = sensorData?.solarCharging
              )
            }

            // Quick Relay Switch on Dashboard (Role Gated)
            item {
              RelayControlCard(
                relayState = relayState,
                thresholds = thresholds,
                currentSoilAvg = sensorData?.soilAverage ?: 50,
                isRaining = sensorData?.isRaining ?: false,
                canControl = isOperator,
                onTogglePump = { viewModel.togglePump(it, context) },
                onSetMode = { viewModel.setRelayMode(it, context) }
              )
            }
          }

          PlantTab.CONTROLS -> {
            // 1. Device Node Power Control
            item {
              NodePowerCard(
                device = selectedDevice,
                isPoweredOn = selectedDevice?.isPoweredOn ?: true,
                canControl = isOperator,
                onTogglePower = { viewModel.toggleDevicePower(it, context) }
              )
            }

            // 2. Relay Switch (Pump ON / OFF + Mode AUTO / MANUAL)
            item {
              RelayControlCard(
                relayState = relayState,
                thresholds = thresholds,
                currentSoilAvg = sensorData?.soilAverage ?: 50,
                isRaining = sensorData?.isRaining ?: false,
                canControl = isOperator,
                onTogglePump = { viewModel.togglePump(it, context) },
                onSetMode = { viewModel.setRelayMode(it, context) }
              )
            }

            // 3. Plant Health & Watering Pulse
            item {
              PlantHealthCard(
                plantHealth = plantHealth,
                isRelayOn = relayState?.isPumpOn == true,
                canControl = isOperator,
                onToggleRelay = { viewModel.togglePump(it, context) }
              )
            }

            // 4. On-Device Autonomous Firmware Limits & Triggers
            item {
              HardwareFirmwareLimitsCard(
                hardwareControls = hardwareControls,
                canControl = isOperator,
                onToggleBuzzer = { viewModel.toggleBuzzer(it, context) },
                onToggleSpeaker = { viewModel.toggleSpeaker(it, context) },
                onToggleLed = { color, turnOn -> viewModel.toggleLed(color, turnOn, context) }
              )
            }

            // 5. Daily Schedule for relay
            item {
              DailyScheduleCard(
                schedule = schedule ?: DailySchedule(),
                canControl = isOperator,
                onUpdateSchedule = { viewModel.updateSchedule(it) }
              )
            }
          }

          PlantTab.CHARTS -> {
            // Dedicated Sensor History Graph Card (limitToLast 200, no CSV export)
            item {
              SensorHistoryGraphCard(historyPoints = history)
            }

            // Telemetry multi-stream chart (no CSV export)
            item {
              TelemetryChartCard(historyPoints = history)
            }

            // Soil Moisture Gauge Overview
            item {
              SoilMoistureGaugesCard(
                zone1 = sensorData?.soilZone1,
                zone2 = sensorData?.soilZone2,
                zone3 = sensorData?.soilZone3,
                dryThreshold = thresholds?.soilDryPercent ?: 35
              )
            }
          }

          PlantTab.PAIR_NODE -> {
            // Direct "Add Device" screen (Device ID, name, location) - listens to /devices/{id}
            item {
              NodePairingScreen(
                existingDevices = allDevices,
                selectedDeviceId = selectedDevice?.id ?: "",
                strings = strings,
                onAddDevice = { id, name, loc ->
                  viewModel.addDevice(id = id, name = name, location = loc)
                  viewModel.selectDevice(id)
                  currentTab = PlantTab.DASHBOARD
                },
                onSelectDevice = { id ->
                  viewModel.selectDevice(id)
                  currentTab = PlantTab.DASHBOARD
                }
              )
            }
          }

          PlantTab.SETTINGS -> {
            // Settings & System Management
            // 1. Alerts & Event Logs (NO CSV EXPORT)
            item {
              AlertsAndLogsView(
                alerts = alerts,
                notificationsEnabled = notificationsEnabled,
                onToggleNotifications = { viewModel.toggleSystemNotifications(it, context) },
                onSendTestNotification = {
                  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                  }
                  viewModel.triggerTestNotification(context)
                },
                onDismissAlert = { viewModel.dismissAlert(it) },
                onClearLogs = { viewModel.clearEventLogs(context) }
              )
            }

            // 2. Device Manager & Map
            item {
              DeviceManagerAndMap(
                devices = allDevices,
                selectedDeviceId = selectedDevice?.id ?: "",
                onSelectDevice = { viewModel.selectDevice(it) },
                onAddDevice = { name, loc, lat, lng -> viewModel.addDevice(id = name.lowercase().replace(" ", "-"), name = name, location = loc, lat = lat, lng = lng) },
                onUpdateLocation = { id, lat, lng, loc -> viewModel.updateDeviceLocation(id, lat, lng, loc) }
              )
            }

            // 3. Backend & Cloud Firebase Configuration
            item {
              FirebaseConfigCard(
                config = firebaseConfig,
                onSaveConfig = { viewModel.saveFirebaseSettings(it, context) }
              )
            }
          }
        }
      }
    }
  }

  // Welcome / Language Selection Dialog
  if (showWelcomeModal) {
    WelcomeLanguageModal(
      currentLanguage = currentLanguage,
      onSelectLanguage = { viewModel.setLanguage(it) },
      onDismiss = { viewModel.dismissWelcomeLanguageModal() }
    )
  }

  // Auth Modal Dialog
  if (showAuthModal) {
    AuthModalDialog(
      isOpen = showAuthModal,
      onDismiss = { showAuthModal = false },
      onSignIn = { email, pass, onResult -> viewModel.signIn(email, pass, onResult) },
      onRegister = { email, pass, displayName, onResult -> viewModel.registerAccount(email, pass, displayName, onResult) }
    )
  }

  // Admin Panel Dialog
  if (showAdminPanel) {
    AdminPanelDialog(
      isOpen = showAdminPanel,
      onDismiss = { showAdminPanel = false },
      viewModel = viewModel
    )
  }

  // Theme Settings Dialog
  if (showThemeDialog) {
    AlertDialog(
      onDismissRequest = { showThemeDialog = false },
      title = { Text("Theme & Color Scheme", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(
            text = "Palette Mode",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Wallpaper Colors (Material You)",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
              )
              Text(
                text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) "Derives theme from system wallpaper (Android 12+)" else "Requires Android 12+ (fallback to nature green)",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Switch(
              checked = themePalette == ThemePalettePreference.WALLPAPER,
              onCheckedChange = {
                viewModel.setThemePalette(if (it) ThemePalettePreference.WALLPAPER else ThemePalettePreference.FIXED_GREEN)
              }
            )
          }

          HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

          Text(
            text = "Dark / Light Setting",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )

          ThemeModePreference.entries.forEach { mode ->
            val isSelected = themeMode == mode
            Surface(
              onClick = { viewModel.setThemeMode(mode) },
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = when (mode) {
                    ThemeModePreference.SYSTEM -> "Follow System Setting"
                    ThemeModePreference.LIGHT -> "Light Theme"
                    ThemeModePreference.DARK -> "Dark Theme"
                  },
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                )
                if (isSelected) {
                  Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                  )
                }
              }
            }
          }
        }
      },
      confirmButton = {
        Button(onClick = { showThemeDialog = false }) {
          Text("Done")
        }
      }
    )
  }

  // Device Quick Switch Modal Sheet
  if (showDeviceSwitcherModal) {
    AlertDialog(
      onDismissRequest = { showDeviceSwitcherModal = false },
      title = {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(imageVector = Icons.Default.Sensors, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Text(text = "Select Guardian Node", fontWeight = FontWeight.Bold)
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          allDevices.forEach { dev ->
            val isSelected = dev.id == selectedDevice?.id
            Surface(
              onClick = {
                viewModel.selectDevice(dev.id)
                showDeviceSwitcherModal = false
              },
              shape = RoundedCornerShape(12.dp),
              color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier.fillMaxWidth().testTag("modal_select_device_${dev.id}")
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(
                    text = dev.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                  )
                  Text(
                    text = "${dev.id} • ${dev.locationName}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
                if (isSelected) {
                  Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showDeviceSwitcherModal = false }) {
          Text("Close")
        }
      }
    )
  }
}
