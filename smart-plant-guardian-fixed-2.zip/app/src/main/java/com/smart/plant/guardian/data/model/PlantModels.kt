package com.smart.plant.guardian.data.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class Device(
  val id: String,
  val name: String,
  val locationName: String,
  val latitude: Double,
  val longitude: Double,
  val firmwareVersion: String = "--",
  val wifiSsid: String = "--",
  val wifiRssi: Int = 0,
  val ipAddress: String = "--",
  val isPoweredOn: Boolean = true,
  val memberUids: List<String> = emptyList()
)

enum class SoilZoneState {
  DRY,   // Below dry threshold
  GOOD,  // Normal moisture range
  WET    // High moisture > 70%
}

data class SensorData(
  val temperatureC: Double? = null,
  val humidityPercent: Double? = null,
  val soilZone1: Int? = null, // 0 - 100%
  val soilZone2: Int? = null,
  val soilZone3: Int? = null,
  val lightLux: Int? = null,
  val lightPercent: Int? = null, // 0 - 100%
  val isRaining: Boolean? = null,
  val batteryPercent: Int? = null, // 0 - 100% calculated by on-device node
  val solarCharging: Boolean? = null, // Optional, null if key missing
  val lastSeenEpochMs: Long? = null
) {
  val temperatureF: Double?
    get() = temperatureC?.let { (it * 9.0 / 5.0) + 32.0 }

  val soilAverage: Int?
    get() {
      val zones = listOfNotNull(soilZone1, soilZone2, soilZone3)
      return if (zones.isNotEmpty()) zones.average().roundToInt() else null
    }

  val lightLevelLabel: String
    get() {
      val pct = lightPercent ?: return "--"
      return when {
        pct < 25 -> "Dark"
        pct <= 65 -> "Dim"
        else -> "Bright"
      }
    }

  fun getZoneState(zoneValue: Int?, dryThreshold: Int): SoilZoneState {
    val z = zoneValue ?: return SoilZoneState.GOOD
    return when {
      z < dryThreshold -> SoilZoneState.DRY
      z > 70 -> SoilZoneState.WET
      else -> SoilZoneState.GOOD
    }
  }

  fun isOnline(currentServerTimeMs: Long = System.currentTimeMillis()): Boolean {
    val seen = lastSeenEpochMs ?: return false
    return (currentServerTimeMs - seen) <= 60_000L
  }

  fun secondsSinceLastSeen(currentServerTimeMs: Long = System.currentTimeMillis()): Long? {
    val seen = lastSeenEpochMs ?: return null
    val diff = (currentServerTimeMs - seen) / 1000L
    return diff.coerceAtLeast(0L)
  }
}

enum class RelayMode {
  AUTO,
  MANUAL
}

data class RelayState(
  val isPumpOn: Boolean = false,
  val mode: RelayMode = RelayMode.AUTO,
  val activeRunSeconds: Int = 0,
  val lastToggledEpochMs: Long = System.currentTimeMillis()
)

data class EcoThresholds(
  val soilDryPercent: Int = 35,
  val soilTargetPercent: Int = 65,
  val highTempAlertThresholdC: Double = 33.0,
  val lowBatteryAlertPercent: Int = 20,
  val maxPumpRunTimeMinutes: Int = 15
)

data class HardwareControls(
  val buzzerActive: Boolean = false,
  val speakerAlertActive: Boolean = false,
  val ledRed: Boolean = false,
  val ledBlue: Boolean = false,
  val ledGreen: Boolean = true,
  val ledYellow: Boolean = false
)

data class DailySchedule(
  val enabled: Boolean = true,
  val startHour: Int = 6,
  val startMinute: Int = 30,
  val durationMinutes: Int = 10,
  val activeDays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7) // 1=Mon, 7=Sun
) {
  fun formattedTime(): String {
    val h = if (startHour < 10) "0$startHour" else "$startHour"
    val m = if (startMinute < 10) "0$startMinute" else "$startMinute"
    return "$h:$m"
  }
}

data class TelemetryPoint(
  val timestampMs: Long,
  val tempC: Double? = null,
  val humidity: Double? = null,
  val soilAvg: Int? = null,
  val zone1: Int? = null,
  val zone2: Int? = null,
  val zone3: Int? = null,
  val lightPercent: Int? = null,
  val lightLux: Int? = null,
  val batteryPercent: Int? = null
) {
  val safeTempC: Double get() = tempC ?: 24.0
  val safeHumidity: Double get() = humidity ?: 60.0
  val safeSoilAvg: Int get() = soilAvg ?: (zone1 ?: 50)
  val safeZone1: Int get() = zone1 ?: 50
  val safeZone2: Int get() = zone2 ?: 50
  val safeZone3: Int get() = zone3 ?: 50
  val safeLightPercent: Int get() = lightPercent ?: ((lightLux ?: 45000) / 1000).coerceIn(0, 100)
  val safeBatteryPercent: Int get() = batteryPercent ?: 85
}

enum class AlertType {
  DRY_SOIL,
  HIGH_TEMP,
  RAIN,
  LOW_BATTERY,
  DEVICE_OFFLINE,
  SYSTEM_INFO
}

enum class AlertSeverity {
  INFO,
  WARNING,
  CRITICAL
}

data class SystemAlert(
  val id: String,
  val type: AlertType,
  val title: String,
  val message: String,
  val severity: AlertSeverity,
  val timestampMs: Long,
  val deviceId: String
) {
  fun formattedTime(): String {
    val sdf = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())
    return sdf.format(Date(timestampMs))
  }
}

data class EventLog(
  val id: String,
  val timestampMs: Long,
  val deviceId: String,
  val type: String,
  val title: String,
  val details: String
) {
  fun formattedTime(): String {
    val sdf = SimpleDateFormat("MMM dd, HH:mm:ss", Locale.getDefault())
    return sdf.format(Date(timestampMs))
  }
}

// User Roles & Authentication Models
enum class UserRole(val roleName: String) {
  ADMIN("admin"),
  OPERATOR("operator"),
  VIEWER("viewer");

  companion object {
    fun fromString(value: String?): UserRole {
      return when (value?.lowercase()?.trim()) {
        "admin" -> ADMIN
        "operator" -> OPERATOR
        else -> VIEWER
      }
    }
  }
}

enum class UserStatus(val statusName: String) {
  PENDING("pending"),
  ACTIVE("active"),
  BLOCKED("blocked");

  companion object {
    fun fromString(value: String?): UserStatus {
      return when (value?.lowercase()?.trim()) {
        "active" -> ACTIVE
        "blocked" -> BLOCKED
        else -> PENDING
      }
    }
  }
}

data class UserProfile(
  val uid: String = "",
  val email: String = "",
  val displayName: String = "",
  val role: UserRole = UserRole.VIEWER,
  val status: UserStatus = UserStatus.PENDING,
  val createdAt: Long = System.currentTimeMillis(),
  val lastLoginMs: Long = System.currentTimeMillis()
) {
  val isActive: Boolean get() = status == UserStatus.ACTIVE
  val isAdmin: Boolean get() = role == UserRole.ADMIN
  val isOperator: Boolean get() = role == UserRole.ADMIN || role == UserRole.OPERATOR
}

data class AuditEntry(
  val id: String = "",
  val uid: String = "",
  val email: String = "",
  val action: String = "",
  val deviceId: String = "",
  val timestampMs: Long = System.currentTimeMillis()
) {
  fun formattedTime(): String {
    val sdf = SimpleDateFormat("MMM dd, HH:mm:ss", Locale.getDefault())
    return sdf.format(Date(timestampMs))
  }
}
