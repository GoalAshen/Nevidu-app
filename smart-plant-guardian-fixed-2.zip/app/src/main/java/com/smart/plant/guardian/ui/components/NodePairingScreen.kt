package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smart.plant.guardian.data.model.Device
import com.smart.plant.guardian.localization.TranslationStrings

@Composable
fun NodePairingScreen(
  existingDevices: List<Device>,
  selectedDeviceId: String,
  strings: TranslationStrings,
  onAddDevice: (id: String, name: String, location: String) -> Unit,
  onSelectDevice: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var deviceId by remember { mutableStateOf("") }
  var deviceName by remember { mutableStateOf("") }
  var locationName by remember { mutableStateOf("") }
  var validationError by remember { mutableStateOf<String?>(null) }
  var successMessage by remember { mutableStateOf<String?>(null) }

  val primaryColor = MaterialTheme.colorScheme.primary

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("node_pairing_screen_card"),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Column(
      modifier = Modifier.padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Box(
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.AddCircleOutline,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(24.dp)
            )
          }
          Column {
            Text(
              text = "Add Guardian Device",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.ExtraBold
            )
            Text(
              text = "Register hardware & listen to /devices/{id}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      // Information Note
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Sensors,
            contentDescription = null,
            tint = primaryColor,
            modifier = Modifier.size(26.dp)
          )
          Column {
            Text(
              text = "Direct Realtime Database Binding",
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
            Text(
              text = "Enter your ESP32 device ID to begin receiving live telemetry from /devices/{id}/sensors, status, and history without pairing delays.",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              lineHeight = 15.sp
            )
          }
        }
      }

      // Input Form
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = deviceId,
          onValueChange = {
            deviceId = it
            validationError = null
            successMessage = null
          },
          label = { Text("Device ID (e.g. ESP32-NODE-01)") },
          placeholder = { Text("ESP32-NODE-01") },
          leadingIcon = {
            Icon(imageVector = Icons.Default.Tag, contentDescription = null, tint = primaryColor)
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_device_id")
        )

        OutlinedTextField(
          value = deviceName,
          onValueChange = {
            deviceName = it
            validationError = null
            successMessage = null
          },
          label = { Text("Device Name (e.g. Greenhouse North Bed)") },
          placeholder = { Text("Greenhouse North Bed") },
          leadingIcon = {
            Icon(imageVector = Icons.Default.Sensors, contentDescription = null, tint = primaryColor)
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_device_name")
        )

        OutlinedTextField(
          value = locationName,
          onValueChange = {
            locationName = it
            validationError = null
            successMessage = null
          },
          label = { Text("Location (e.g. Zone 1, Nursery Alpha)") },
          placeholder = { Text("Zone 1, Nursery Alpha") },
          leadingIcon = {
            Icon(imageVector = Icons.Default.Place, contentDescription = null, tint = primaryColor)
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_device_location")
        )

        if (validationError != null) {
          Text(
            text = validationError ?: "",
            color = MaterialTheme.colorScheme.error,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }

        if (successMessage != null) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
              )
              Text(
                text = successMessage ?: "",
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        Button(
          onClick = {
            val cleanId = deviceId.trim()
            if (cleanId.isBlank()) {
              validationError = "Please enter a valid Device ID (e.g. ESP32-NODE-01)"
              return@Button
            }
            val cleanName = deviceName.trim().ifBlank { cleanId }
            val cleanLoc = locationName.trim().ifBlank { "Greenhouse Zone" }
            onAddDevice(cleanId, cleanName, cleanLoc)
            successMessage = "Device $cleanId added! Now listening to /devices/$cleanId"
            deviceId = ""
            deviceName = ""
            locationName = ""
          },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = primaryColor,
            contentColor = MaterialTheme.colorScheme.onPrimary
          ),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("add_device_submit_button")
        ) {
          Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "Add Device & Start Listening", fontWeight = FontWeight.Bold)
        }
      }

      // Existing Devices List
      if (existingDevices.isNotEmpty()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "Active Hardware Fleet (${existingDevices.size})",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          existingDevices.forEach { dev ->
            val isCurrent = dev.id == selectedDeviceId
            Surface(
              onClick = { onSelectDevice(dev.id) },
              shape = RoundedCornerShape(14.dp),
              color = if (isCurrent) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
              border = if (isCurrent) CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(primaryColor)
              ) else null,
              modifier = Modifier
                .fillMaxWidth()
                .testTag("existing_device_${dev.id}")
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                  Box(
                    modifier = Modifier
                      .size(10.dp)
                      .clip(CircleShape)
                      .background(if (isCurrent) primaryColor else MaterialTheme.colorScheme.outline)
                  )
                  Column {
                    Text(
                      text = dev.name,
                      style = MaterialTheme.typography.titleSmall,
                      fontWeight = FontWeight.Bold,
                      color = if (isCurrent) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = "${dev.id} • ${dev.locationName}",
                      fontSize = 11.sp,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }

                if (isCurrent) {
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = primaryColor
                  ) {
                    Text(
                      text = "LISTENING",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.ExtraBold,
                      color = MaterialTheme.colorScheme.onPrimary,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
