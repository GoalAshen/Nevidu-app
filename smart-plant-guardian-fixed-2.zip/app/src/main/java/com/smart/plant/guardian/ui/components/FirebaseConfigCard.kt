package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.smart.plant.guardian.data.remote.FirebaseSettings

@Composable
fun FirebaseConfigCard(
  config: FirebaseSettings,
  onSaveConfig: (FirebaseSettings) -> Unit,
  modifier: Modifier = Modifier
) {
  var dbUrl by remember(config.databaseUrl) { mutableStateOf(config.databaseUrl) }
  var apiKey by remember(config.apiKey) { mutableStateOf(config.apiKey) }
  var projectId by remember(config.projectId) { mutableStateOf(config.projectId) }
  var appId by remember(config.appId) { mutableStateOf(config.appId) }
  var ownerEmail by remember(config.ownerEmail) { mutableStateOf(config.ownerEmail) }
  var authPassword by remember(config.authPassword) { mutableStateOf(config.authPassword) }
  var showPassword by remember { mutableStateOf(false) }
  val isConfigured = config.databaseUrl.isNotBlank() && config.apiKey.isNotBlank() && config.appId.isNotBlank()

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("firebase_config_card"),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceContainer
    ),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.tertiaryContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Cloud,
              contentDescription = "Firebase",
              tint = MaterialTheme.colorScheme.onTertiaryContainer,
              modifier = Modifier.size(22.dp)
            )
          }
          Column {
            Text(
              text = "Firebase RTDB & Backend",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Realtime Database & Telemetry Paths",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        // Setup status badge
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (isConfigured) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
        ) {
          Text(
            text = if (isConfigured) "CONFIGURED" else "NOT SET UP",
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (isConfigured) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer
          )
        }
      }

      // Backend RTDB Schema Paths Visualizer
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
          text = "Registered Node Data Paths (Owner & Role Based):",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        val paths = listOf(
          FirebaseSettings.PATH_SENSORS to "Climate, Light, Rain, Battery %, Soil Zones 1-3",
          FirebaseSettings.PATH_STATUS to "pumpOn, mode (AUTO/MANUAL), activeRunSeconds",
          FirebaseSettings.PATH_COMMANDS to "power, pump, mode, buzzer, speaker, LEDs",
          FirebaseSettings.PATH_SETTINGS to "soilDryPercent, highTempAlertThresholdC, lowBatteryAlertPercent",
          FirebaseSettings.PATH_HISTORY to "Timestamped telemetry points (read-only, limit 200)"
        )
        paths.forEach { (path, desc) ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = path,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = desc,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }

      // Firebase Credentials Form
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Firebase Credentials & Project Keys",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold
        )

        OutlinedTextField(
          value = dbUrl,
          onValueChange = { dbUrl = it },
          label = { Text("Database URL (RTDB)") },
          placeholder = { Text("https://my-plant-default-rtdb.firebaseio.com") },
          modifier = Modifier.fillMaxWidth().testTag("input_db_url"),
          singleLine = true
        )

        OutlinedTextField(
          value = apiKey,
          onValueChange = { apiKey = it },
          label = { Text("Firebase Web API Key") },
          placeholder = { Text("AIzaSy...") },
          modifier = Modifier.fillMaxWidth().testTag("input_api_key"),
          singleLine = true
        )

        OutlinedTextField(
          value = appId,
          onValueChange = { appId = it },
          label = { Text("Firebase App ID (1:123456789:android:abcdef)") },
          placeholder = { Text("1:123456789:android:abcdef") },
          modifier = Modifier.fillMaxWidth().testTag("input_app_id"),
          singleLine = true
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = projectId,
            onValueChange = { projectId = it },
            label = { Text("Project ID") },
            placeholder = { Text("my-plant-project") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
          OutlinedTextField(
            value = ownerEmail,
            onValueChange = { ownerEmail = it },
            label = { Text("Admin Email") },
            placeholder = { Text("admin@example.com") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        OutlinedTextField(
          value = authPassword,
          onValueChange = { authPassword = it },
          label = { Text("Auth Password (Firebase Auth)") },
          modifier = Modifier.fillMaxWidth().testTag("input_auth_password"),
          singleLine = true,
          visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
          trailingIcon = {
            IconButton(onClick = { showPassword = !showPassword }) {
              Icon(
                imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                contentDescription = if (showPassword) "Hide password" else "Show password"
              )
            }
          }
        )

        Button(
          onClick = {
            onSaveConfig(
              config.copy(
                databaseUrl = dbUrl.trim(),
                apiKey = apiKey.trim(),
                projectId = projectId.trim(),
                appId = appId.trim(),
                ownerEmail = ownerEmail.trim(),
                authPassword = authPassword
              )
            )
          },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("save_firebase_config_button")
        ) {
          Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "Save Firebase Configuration", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
