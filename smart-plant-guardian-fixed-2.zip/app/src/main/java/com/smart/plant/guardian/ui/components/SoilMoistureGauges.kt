package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Grass
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smart.plant.guardian.data.model.SoilZoneState

@Composable
fun SoilMoistureGaugesCard(
  zone1: Int?,
  zone2: Int?,
  zone3: Int?,
  dryThreshold: Int,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("soil_moisture_gauges_card"),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.Grass,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Column {
            Text(
              text = "Soil Moisture Profiles",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Tri-depth capacitive root sensors",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
      ) {
        CircularSoilGauge(
          title = "Topsoil",
          depth = "5 cm",
          value = zone1,
          dryThreshold = dryThreshold,
          modifier = Modifier.testTag("gauge_zone1")
        )
        CircularSoilGauge(
          title = "Root Core",
          depth = "15 cm",
          value = zone2,
          dryThreshold = dryThreshold,
          modifier = Modifier.testTag("gauge_zone2")
        )
        CircularSoilGauge(
          title = "Deep Bed",
          depth = "30 cm",
          value = zone3,
          dryThreshold = dryThreshold,
          modifier = Modifier.testTag("gauge_zone3")
        )
      }
    }
  }
}

@Composable
fun CircularSoilGauge(
  title: String,
  depth: String,
  value: Int?,
  dryThreshold: Int,
  modifier: Modifier = Modifier
) {
  val state = when {
    value == null -> null
    value < dryThreshold -> SoilZoneState.DRY
    value > 70 -> SoilZoneState.WET
    else -> SoilZoneState.GOOD
  }

  // Derive status colors directly from theme scheme per Section H
  val stateColor = when (state) {
    SoilZoneState.DRY -> MaterialTheme.colorScheme.error
    SoilZoneState.GOOD -> MaterialTheme.colorScheme.primary
    SoilZoneState.WET -> MaterialTheme.colorScheme.tertiary
    null -> MaterialTheme.colorScheme.onSurfaceVariant
  }

  val stateLabel = when (state) {
    SoilZoneState.DRY -> "DRY"
    SoilZoneState.GOOD -> "GOOD"
    SoilZoneState.WET -> "WET"
    null -> "--"
  }

  Column(
    modifier = modifier,
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier.size(80.dp)
    ) {
      val progress = value?.let { it.toFloat() / 100f } ?: 0f
      CircularProgressIndicator(
        progress = { progress },
        modifier = Modifier.fillMaxSize(),
        color = stateColor,
        trackColor = MaterialTheme.colorScheme.surfaceVariant,
        strokeWidth = 8.dp
      )
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = value?.let { "$it%" } ?: "--",
          fontSize = 16.sp,
          fontWeight = FontWeight.ExtraBold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = stateLabel,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold,
          color = stateColor
        )
      }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = title,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = depth,
        fontSize = 10.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}
