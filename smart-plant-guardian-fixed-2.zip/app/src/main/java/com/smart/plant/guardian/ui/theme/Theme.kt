package com.smart.plant.guardian.ui.theme

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

enum class ThemePalettePreference {
  WALLPAPER,
  FIXED_GREEN
}

enum class ThemeModePreference {
  SYSTEM,
  LIGHT,
  DARK
}

private val LightColorScheme = lightColorScheme(
  primary = ForestGreenPrimary,
  onPrimary = ForestGreenOnPrimary,
  primaryContainer = ForestGreenPrimaryContainer,
  onPrimaryContainer = ForestGreenOnPrimaryContainer,
  secondary = AquaSecondary,
  onSecondary = AquaOnSecondary,
  secondaryContainer = AquaSecondaryContainer,
  onSecondaryContainer = AquaOnSecondaryContainer,
  tertiary = PlantTertiary,
  onTertiary = PlantOnTertiary,
  tertiaryContainer = PlantTertiaryContainer,
  onTertiaryContainer = PlantOnTertiaryContainer,
  error = StatusDryError,
  onError = StatusDryOnError,
  errorContainer = StatusDryErrorContainer,
  background = Color(0xFFF6FBF6),
  onBackground = Color(0xFF181D1A),
  surface = Color(0xFFF6FBF6),
  onSurface = Color(0xFF181D1A),
  surfaceVariant = Color(0xFFDCE5DD),
  onSurfaceVariant = Color(0xFF404943),
  outline = Color(0xFF707973)
)

private val DarkColorScheme = darkColorScheme(
  primary = DarkForestGreenPrimary,
  onPrimary = DarkForestGreenOnPrimary,
  primaryContainer = DarkForestGreenPrimaryContainer,
  onPrimaryContainer = DarkForestGreenOnPrimaryContainer,
  secondary = DarkAquaSecondary,
  onSecondary = DarkAquaOnSecondary,
  secondaryContainer = DarkAquaSecondaryContainer,
  onSecondaryContainer = DarkAquaOnSecondaryContainer,
  tertiary = DarkPlantTertiary,
  onTertiary = DarkPlantOnTertiary,
  tertiaryContainer = DarkPlantTertiaryContainer,
  onTertiaryContainer = DarkPlantOnTertiaryContainer,
  error = DarkStatusDryError,
  errorContainer = DarkStatusDryErrorContainer,
  background = Color(0xFF0F1512),
  onBackground = Color(0xFFDFE4DF),
  surface = Color(0xFF0F1512),
  onSurface = Color(0xFFDFE4DF),
  surfaceVariant = Color(0xFF404943),
  onSurfaceVariant = Color(0xFFBFC9C2),
  outline = Color(0xFF8A938C)
)

val SmartPlantShapes = Shapes(
  small = RoundedCornerShape(12.dp),
  medium = RoundedCornerShape(18.dp),
  large = RoundedCornerShape(28.dp),
  extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun SmartPlantGuardianTheme(
  themeMode: ThemeModePreference = ThemeModePreference.SYSTEM,
  themePalette: ThemePalettePreference = ThemePalettePreference.WALLPAPER,
  content: @Composable () -> Unit
) {
  val darkTheme = when (themeMode) {
    ThemeModePreference.SYSTEM -> isSystemInDarkTheme()
    ThemeModePreference.LIGHT -> false
    ThemeModePreference.DARK -> true
  }

  val context = LocalContext.current
  val isDynamicSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
  val useDynamic = themePalette == ThemePalettePreference.WALLPAPER && isDynamicSupported

  val baseColorScheme = when {
    useDynamic && darkTheme -> dynamicDarkColorScheme(context)
    useDynamic && !darkTheme -> dynamicLightColorScheme(context)
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  // Smooth animated color transitions between light and dark
  val animatedPrimary = animateColorAsState(baseColorScheme.primary, animationSpec = tween(350), label = "primary").value
  val animatedPrimaryContainer = animateColorAsState(baseColorScheme.primaryContainer, animationSpec = tween(350), label = "primaryContainer").value
  val animatedSurface = animateColorAsState(baseColorScheme.surface, animationSpec = tween(350), label = "surface").value
  val animatedSurfaceVariant = animateColorAsState(baseColorScheme.surfaceVariant, animationSpec = tween(350), label = "surfaceVariant").value
  val animatedBackground = animateColorAsState(baseColorScheme.background, animationSpec = tween(350), label = "background").value
  val animatedOnSurface = animateColorAsState(baseColorScheme.onSurface, animationSpec = tween(350), label = "onSurface").value

  val animatedColorScheme = baseColorScheme.copy(
    primary = animatedPrimary,
    primaryContainer = animatedPrimaryContainer,
    surface = animatedSurface,
    surfaceVariant = animatedSurfaceVariant,
    background = animatedBackground,
    onSurface = animatedOnSurface
  )

  MaterialTheme(
    colorScheme = animatedColorScheme,
    typography = Typography,
    shapes = SmartPlantShapes,
    content = content
  )
}

@Preview(name = "Light Nature Theme", showBackground = true)
@Composable
fun PreviewSmartPlantThemeLight() {
  SmartPlantGuardianTheme(
    themeMode = ThemeModePreference.LIGHT,
    themePalette = ThemePalettePreference.FIXED_GREEN
  ) {
    Surface(color = MaterialTheme.colorScheme.background) {
      Text(
        text = "Smart Plant Guardian",
        style = MaterialTheme.typography.headlineMedium,
        color = MaterialTheme.colorScheme.primary
      )
    }
  }
}

@Preview(name = "Dark Nature Theme", showBackground = true)
@Composable
fun PreviewSmartPlantThemeDark() {
  SmartPlantGuardianTheme(
    themeMode = ThemeModePreference.DARK,
    themePalette = ThemePalettePreference.FIXED_GREEN
  ) {
    Surface(color = MaterialTheme.colorScheme.background) {
      Text(
        text = "Smart Plant Guardian",
        style = MaterialTheme.typography.headlineMedium,
        color = MaterialTheme.colorScheme.primary
      )
    }
  }
}
