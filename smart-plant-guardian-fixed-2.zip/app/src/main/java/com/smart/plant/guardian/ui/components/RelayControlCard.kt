package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smart.plant.guardian.data.model.Device
import com.smart.plant.guardian.data.model.EcoThresholds
import com.smart.plant.guardian.data.model.RelayMode
import com.smart.plant.guardian.data.model.RelayState

@Composable
fun RelayControlCard(
  relayState: RelayState?,
  thresholds: EcoThresholds?,
  currentSoilAvg: Int?,
  isRaining: Boolean,
  canControl: Boolean,
  onTogglePump: (Boolean) -> Unit,
  onSetMode: (RelayMode) -> Unit,
  modifier: Modifier = Modifier
) {
  val isPumpOn = relayState?.isPumpOn ?: false
  val mode = relayState?.mode ?: RelayMode.AUTO

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("relay_control_card"),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = if (isPumpOn) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.WaterDrop,
                contentDescription = null,
                tint = if (isPumpOn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Column {
            Text(
              text = "Irrigation Water Pump",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = if (isPumpOn) "Pump actively running (${relayState?.activeRunSeconds ?: 0}s)" else "Relay standby",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        // Live Mode Pill
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = if (mode == RelayMode.AUTO) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.tertiaryContainer
        ) {
          Text(
            text = mode.name,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (mode == RelayMode.AUTO) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onTertiaryContainer,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      if (!canControl) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.PowerSettingsNew, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
            Text("Viewer Mode: Hardware control switches are read-only.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Mode Selector (Auto / Manual)
        FilterChip(
          selected = mode == RelayMode.AUTO,
          onClick = { if (canControl) onSetMode(RelayMode.AUTO) },
          enabled = canControl,
          label = { Text("Autonomous Mode") },
          modifier = Modifier.weight(1f).testTag("relay_mode_auto")
        )
        FilterChip(
          selected = mode == RelayMode.MANUAL,
          onClick = { if (canControl) onSetMode(RelayMode.MANUAL) },
          enabled = canControl,
          label = { Text("Manual Override") },
          modifier = Modifier.weight(1f).testTag("relay_mode_manual")
        )
      }

      // Main Pump Power Button
      Button(
        onClick = { if (canControl) onTogglePump(!isPumpOn) },
        enabled = canControl,
        colors = ButtonDefaults.buttonColors(
          containerColor = if (isPumpOn) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().testTag("toggle_pump_button")
      ) {
        Icon(imageVector = Icons.Default.PowerSettingsNew, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (isPumpOn) "Turn Pump OFF" else "Turn Pump ON",
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp
        )
      }
    }
  }
}

@Composable
fun NodePowerCard(
  device: Device?,
  isPoweredOn: Boolean,
  canControl: Boolean,
  onTogglePower: (Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("node_power_card"),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Surface(
          shape = CircleShape,
          color = if (isPoweredOn) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
          modifier = Modifier.size(40.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Default.PowerSettingsNew,
              contentDescription = null,
              tint = if (isPoweredOn) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
              modifier = Modifier.size(22.dp)
            )
          }
        }
        Column {
          Text(
            text = "Hardware Power State",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = if (isPoweredOn) "${device?.name ?: "Node"} is Online & Actively Monitoring" else "Node is Powered Down",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Switch(
        checked = isPoweredOn,
        onCheckedChange = { if (canControl) onTogglePower(it) },
        enabled = canControl,
        modifier = Modifier.testTag("node_power_switch")
      )
    }
  }
}

