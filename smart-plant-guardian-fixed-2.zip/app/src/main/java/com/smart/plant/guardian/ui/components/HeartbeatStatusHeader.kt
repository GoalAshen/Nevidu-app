package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.SensorsOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smart.plant.guardian.data.model.Device
import com.smart.plant.guardian.data.model.SensorData
import com.smart.plant.guardian.data.model.UserProfile
import com.smart.plant.guardian.data.model.UserRole

@Composable
fun HeartbeatStatusHeader(
  device: Device?,
  sensorData: SensorData?,
  isOnline: Boolean,
  currentUser: UserProfile?,
  onDeviceSwitchClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val lastSeenSec = sensorData?.secondsSinceLastSeen() ?: 0L

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("heartbeat_status_header"),
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Surface(
          shape = CircleShape,
          color = if (isOnline) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
          modifier = Modifier.size(38.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (isOnline) Icons.Default.Sensors else Icons.Default.SensorsOff,
              contentDescription = null,
              tint = if (isOnline) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
              modifier = Modifier.size(20.dp)
            )
          }
        }

        Column {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Text(
              text = device?.name ?: "Eco Node",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              maxLines = 1
            )
            // Online/Offline Pill
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = if (isOnline) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            ) {
              Text(
                text = if (isOnline) "ONLINE" else "OFFLINE",
                fontSize = 9.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isOnline) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onError,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }

          Text(
            text = if (isOnline) {
              "Live Telemetry • Last seen: ${lastSeenSec}s ago"
            } else {
              if (sensorData == null) "Waiting for device data…" else "Heartbeat lost (${lastSeenSec}s ago > 60s limit)"
            },
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      // Switch Node Pill
      Surface(
        onClick = onDeviceSwitchClick,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.testTag("header_switch_device_button")
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Text(
            text = device?.id ?: "Switch",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Icon(
            imageVector = Icons.Default.ArrowDropDown,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
