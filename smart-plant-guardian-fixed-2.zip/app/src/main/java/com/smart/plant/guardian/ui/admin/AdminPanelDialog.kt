package com.smart.plant.guardian.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.smart.plant.guardian.data.model.*
import com.smart.plant.guardian.ui.viewmodel.PlantGuardianViewModel

enum class AdminTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
  USERS("Users", Icons.Default.People),
  DEVICES("Devices", Icons.Default.Sensors),
  GLOBAL_SETTINGS("Global", Icons.Default.Tune),
  ACTIVITY_LOG("Audit Log", Icons.Default.History),
  EMERGENCY("Emergency", Icons.Default.Warning)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelDialog(
  isOpen: Boolean,
  onDismiss: () -> Unit,
  viewModel: PlantGuardianViewModel
) {
  if (!isOpen) return

  var currentTab by remember { mutableStateOf(AdminTab.USERS) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Scaffold(
      topBar = {
        TopAppBar(
          title = {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(36.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(20.dp)
                  )
                }
              }
              Column {
                Text(
                  text = "Administrator Control Center",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "Security, Fleets, Global Rules & Audit",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          },
          actions = {
            IconButton(onClick = onDismiss) {
              Icon(imageVector = Icons.Default.Close, contentDescription = "Close Admin Panel")
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
          )
        )
      },
      bottomBar = {
        NavigationBar(
          containerColor = MaterialTheme.colorScheme.surface,
          tonalElevation = 8.dp
        ) {
          AdminTab.entries.forEach { tab ->
            val isSelected = currentTab == tab
            NavigationBarItem(
              selected = isSelected,
              onClick = { currentTab = tab },
              icon = { Icon(tab.icon, contentDescription = tab.title) },
              label = { Text(tab.title, fontSize = 10.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
              colors = NavigationBarItemDefaults.colors(
                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                selectedTextColor = MaterialTheme.colorScheme.primary
              )
            )
          }
        }
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .padding(horizontal = 16.dp, vertical = 8.dp)
      ) {
        when (currentTab) {
          AdminTab.USERS -> AdminUsersTab(viewModel)
          AdminTab.DEVICES -> AdminDevicesTab(viewModel)
          AdminTab.GLOBAL_SETTINGS -> AdminGlobalSettingsTab(viewModel)
          AdminTab.ACTIVITY_LOG -> AdminAuditLogTab(viewModel)
          AdminTab.EMERGENCY -> AdminEmergencyTab(viewModel)
        }
      }
    }
  }
}

// =========================================================================
// TAB 1: USERS
// =========================================================================

@Composable
fun AdminUsersTab(viewModel: PlantGuardianViewModel) {
  val users by viewModel.allUsers.collectAsState()
  val devices by viewModel.allDevices.collectAsState()
  var searchQuery by remember { mutableStateOf("") }
  var filterStatus by remember { mutableStateOf<UserStatus?>(null) }

  val filteredUsers = remember(users, searchQuery, filterStatus) {
    users.filter { u ->
      (filterStatus == null || u.status == filterStatus) &&
        (searchQuery.isBlank() || u.email.contains(searchQuery, ignoreCase = true) || u.displayName.contains(searchQuery, ignoreCase = true))
    }
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        label = { Text("Search users by email or name") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp)
      )
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        FilterChip(
          selected = filterStatus == null,
          onClick = { filterStatus = null },
          label = { Text("All (${users.size})") }
        )
        FilterChip(
          selected = filterStatus == UserStatus.PENDING,
          onClick = { filterStatus = if (filterStatus == UserStatus.PENDING) null else UserStatus.PENDING },
          label = { Text("Pending") }
        )
        FilterChip(
          selected = filterStatus == UserStatus.ACTIVE,
          onClick = { filterStatus = if (filterStatus == UserStatus.ACTIVE) null else UserStatus.ACTIVE },
          label = { Text("Active") }
        )
        FilterChip(
          selected = filterStatus == UserStatus.BLOCKED,
          onClick = { filterStatus = if (filterStatus == UserStatus.BLOCKED) null else UserStatus.BLOCKED },
          label = { Text("Blocked") }
        )
      }
    }

    if (filteredUsers.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        ) {
          Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("No users found matching query", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }

    items(filteredUsers, key = { it.uid }) { user ->
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = user.displayName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
              Text(text = user.email, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = when (user.status) {
                UserStatus.ACTIVE -> MaterialTheme.colorScheme.primaryContainer
                UserStatus.PENDING -> MaterialTheme.colorScheme.tertiaryContainer
                UserStatus.BLOCKED -> MaterialTheme.colorScheme.errorContainer
              }
            ) {
              Text(
                text = user.status.statusName.uppercase(),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = when (user.status) {
                  UserStatus.ACTIVE -> MaterialTheme.colorScheme.onPrimaryContainer
                  UserStatus.PENDING -> MaterialTheme.colorScheme.onTertiaryContainer
                  UserStatus.BLOCKED -> MaterialTheme.colorScheme.onErrorContainer
                },
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(text = "Role: ${user.role.roleName.replaceFirstChar { it.uppercase() }}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              if (user.status == UserStatus.PENDING) {
                Button(
                  onClick = { viewModel.approveUser(user.uid) },
                  shape = RoundedCornerShape(8.dp),
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                  Text("Approve", fontSize = 11.sp)
                }
              }

              // Change Role Dropdown Trigger
              var roleMenuOpen by remember { mutableStateOf(false) }
              Box {
                OutlinedButton(
                  onClick = { roleMenuOpen = true },
                  shape = RoundedCornerShape(8.dp),
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                  Text("Role", fontSize = 11.sp)
                }
                DropdownMenu(expanded = roleMenuOpen, onDismissRequest = { roleMenuOpen = false }) {
                  UserRole.entries.forEach { r ->
                    DropdownMenuItem(
                      text = { Text(r.roleName.replaceFirstChar { it.uppercase() }) },
                      onClick = {
                        viewModel.updateUserRole(user.uid, r)
                        roleMenuOpen = false
                      }
                    )
                  }
                }
              }

              // Block / Unblock Toggle
              OutlinedButton(
                onClick = {
                  val newS = if (user.status == UserStatus.BLOCKED) UserStatus.ACTIVE else UserStatus.BLOCKED
                  viewModel.updateUserStatus(user.uid, newS)
                },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
              ) {
                Text(if (user.status == UserStatus.BLOCKED) "Unblock" else "Block", fontSize = 11.sp)
              }
            }
          }
        }
      }
    }
  }
}

// =========================================================================
// TAB 2: DEVICES
// =========================================================================

@Composable
fun AdminDevicesTab(viewModel: PlantGuardianViewModel) {
  val devices by viewModel.allDevices.collectAsState()
  val sensorDataMap by viewModel.repository.sensorDataMap.collectAsState()
  var showAddDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "Device Fleet Management", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          Text(text = "${devices.size} Nodes Registered", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Button(
          onClick = { showAddDialog = true },
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Add Node", fontSize = 12.sp)
        }
      }
    }

    items(devices, key = { it.id }) { dev ->
      val sensor = sensorDataMap[dev.id]
      val isOnline = sensor?.isOnline(viewModel.repository.getSynchronizedServerTime()) ?: false

      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = dev.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
              Text(text = "${dev.id} • ${dev.locationName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isOnline) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
            ) {
              Text(
                text = if (isOnline) "ONLINE" else "OFFLINE",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (isOnline) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Battery: ${sensor?.batteryPercent?.let { "$it%" } ?: "--"} • Last: ${sensor?.secondsSinceLastSeen(viewModel.repository.getSynchronizedServerTime())?.let { "${it}s ago" } ?: "--"}",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            IconButton(
              onClick = { viewModel.removeDevice(dev.id) },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(Icons.Default.DeleteOutline, contentDescription = "Remove Device", tint = MaterialTheme.colorScheme.error)
            }
          }
        }
      }
    }
  }

  if (showAddDialog) {
    var devId by remember { mutableStateOf("") }
    var devName by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }

    AlertDialog(
      onDismissRequest = { showAddDialog = false },
      title = { Text("Add Hardware Device Node") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(value = devId, onValueChange = { devId = it }, label = { Text("Device ID (e.g. NODE-04)") }, singleLine = true)
          OutlinedTextField(value = devName, onValueChange = { devName = it }, label = { Text("Device Name") }, singleLine = true)
          OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Location Name") }, singleLine = true)
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (devId.isNotBlank()) {
              viewModel.addDevice(devId, devName, location)
              showAddDialog = false
            }
          }
        ) {
          Text("Add")
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
      }
    )
  }
}

// =========================================================================
// TAB 3: GLOBAL SETTINGS
// =========================================================================

@Composable
fun AdminGlobalSettingsTab(viewModel: PlantGuardianViewModel) {
  var dryThreshold by remember { mutableStateOf(35f) }
  var targetThreshold by remember { mutableStateOf(65f) }
  var tempAlert by remember { mutableStateOf(33f) }
  var batteryAlert by remember { mutableStateOf(20f) }
  var maxRunMinutes by remember { mutableStateOf(15f) }
  var showConfirmDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Text(
        text = "Global Microclimate Defaults",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = "Standard thresholds automatically assigned to new nodes, with batch push capability.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    item {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
          Text(text = "Soil Moisture Trigger: ${dryThreshold.toInt()}%", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Slider(value = dryThreshold, onValueChange = { dryThreshold = it }, valueRange = 10f..60f)

          Text(text = "Target Soil Moisture: ${targetThreshold.toInt()}%", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Slider(value = targetThreshold, onValueChange = { targetThreshold = it }, valueRange = 40f..85f)

          Text(text = "High Temp Alert Limit: ${tempAlert.toInt()}°C", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Slider(value = tempAlert, onValueChange = { tempAlert = it }, valueRange = 25f..45f)

          Text(text = "Low Battery Warning: ${batteryAlert.toInt()}%", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Slider(value = batteryAlert, onValueChange = { batteryAlert = it }, valueRange = 10f..35f)

          Text(text = "Maximum Single Pump Run: ${maxRunMinutes.toInt()} min", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Slider(value = maxRunMinutes, onValueChange = { maxRunMinutes = it }, valueRange = 3f..45f)
        }
      }
    }

    item {
      Button(
        onClick = { showConfirmDialog = true },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp)
      ) {
        Icon(Icons.Default.Sync, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Apply to All Devices", fontWeight = FontWeight.Bold)
      }
    }
  }

  if (showConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showConfirmDialog = false },
      title = { Text("Confirm Batch Threshold Update") },
      text = {
        Text("Are you sure you want to overwrite environmental thresholds for ALL connected nodes with these global values?")
      },
      confirmButton = {
        Button(
          onClick = {
            val global = EcoThresholds(
              soilDryPercent = dryThreshold.toInt(),
              soilTargetPercent = targetThreshold.toInt(),
              highTempAlertThresholdC = tempAlert.toDouble(),
              lowBatteryAlertPercent = batteryAlert.toInt(),
              maxPumpRunTimeMinutes = maxRunMinutes.toInt()
            )
            viewModel.applyGlobalThresholds(global)
            showConfirmDialog = false
          }
        ) {
          Text("Overwrite All")
        }
      },
      dismissButton = {
        TextButton(onClick = { showConfirmDialog = false }) { Text("Cancel") }
      }
    )
  }
}

// =========================================================================
// TAB 4: ACTIVITY AUDIT LOG (NO CSV EXPORT)
// =========================================================================

@Composable
fun AdminAuditLogTab(viewModel: PlantGuardianViewModel) {
  val logs by viewModel.auditLogs.collectAsState()
  var searchAction by remember { mutableStateOf("") }

  val filteredLogs = remember(logs, searchAction) {
    if (searchAction.isBlank()) logs
    else logs.filter { it.action.contains(searchAction, ignoreCase = true) || it.email.contains(searchAction, ignoreCase = true) }
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      OutlinedTextField(
        value = searchAction,
        onValueChange = { searchAction = it },
        label = { Text("Filter audit trail by action or user") },
        leadingIcon = { Icon(Icons.Default.FilterList, contentDescription = null) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp)
      )
    }

    if (filteredLogs.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        ) {
          Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("No activity log entries recorded", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }

    items(filteredLogs, key = { it.id }) { log ->
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = log.action, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            Text(text = log.formattedTime(), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Text(text = "Actor: ${if (log.email.isNotBlank()) log.email else log.uid.take(12)} • Node: ${log.deviceId.ifBlank { "System" }}", fontSize = 11.sp)
        }
      }
    }
  }
}

// =========================================================================
// TAB 5: EMERGENCY CONTROLS
// =========================================================================

@Composable
fun AdminEmergencyTab(viewModel: PlantGuardianViewModel) {
  var showPumpConfirm by remember { mutableStateOf(false) }
  var showManualConfirm by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
            Text("Emergency System Overrides", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
          }
          Text(
            text = "Use these emergency interventions in the event of hardware malfunction, plumbing leak, or network desynchronization.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onErrorContainer
          )
        }
      }
    }

    item {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text("Kill Switch: Turn ALL Pumps OFF", fontWeight = FontWeight.Bold)
          Text("Immediately broadcasts a forced pump OFF command to every node in the fleet.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Button(
            onClick = { showPumpConfirm = true },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.PowerSettingsNew, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Shut Down All Pumps", color = MaterialTheme.colorScheme.onError)
          }
        }
      }
    }

    item {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text("Force MANUAL Mode Fleet-wide", fontWeight = FontWeight.Bold)
          Text("Halts all automated timers, moisture triggers, and schedules across all devices.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Button(
            onClick = { showManualConfirm = true },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.Tune, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Force All to MANUAL")
          }
        }
      }
    }
  }

  if (showPumpConfirm) {
    AlertDialog(
      onDismissRequest = { showPumpConfirm = false },
      title = { Text("Emergency: Stop All Pumps?") },
      text = { Text("This will broadcast a shutoff command to all irrigation relays immediately.") },
      confirmButton = {
        Button(
          onClick = {
            viewModel.emergencyTurnAllPumpsOff()
            showPumpConfirm = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
          Text("Confirm Shutoff", color = MaterialTheme.colorScheme.onError)
        }
      },
      dismissButton = {
        TextButton(onClick = { showPumpConfirm = false }) { Text("Cancel") }
      }
    )
  }

  if (showManualConfirm) {
    AlertDialog(
      onDismissRequest = { showManualConfirm = false },
      title = { Text("Force MANUAL Mode Fleet-wide?") },
      text = { Text("All autonomous timers and soil triggers will be halted across all devices.") },
      confirmButton = {
        Button(
          onClick = {
            viewModel.emergencyForceManualModeAll()
            showManualConfirm = false
          }
        ) {
          Text("Confirm Override")
        }
      },
      dismissButton = {
        TextButton(onClick = { showManualConfirm = false }) { Text("Cancel") }
      }
    )
  }
}
