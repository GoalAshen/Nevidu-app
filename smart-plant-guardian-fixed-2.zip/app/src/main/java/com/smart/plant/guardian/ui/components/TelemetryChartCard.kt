package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Grass
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smart.plant.guardian.data.model.TelemetryPoint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ChartMetricType(val title: String, val unit: String) {
  TEMPERATURE("Temperature", "°C"),
  HUMIDITY("Humidity", "%"),
  SOIL_MOISTURE("Soil Moisture", "%")
}

@Composable
fun TelemetryChartCard(
  historyPoints: List<TelemetryPoint>,
  modifier: Modifier = Modifier
) {
  var selectedMetric by remember { mutableStateOf(ChartMetricType.TEMPERATURE) }
  var touchedIndex by remember { mutableStateOf<Int?>(null) }

  val metricColor = when (selectedMetric) {
    ChartMetricType.TEMPERATURE -> MaterialTheme.colorScheme.primary
    ChartMetricType.HUMIDITY -> MaterialTheme.colorScheme.tertiary
    ChartMetricType.SOIL_MOISTURE -> MaterialTheme.colorScheme.secondary
  }

  val filteredPoints = remember(historyPoints) {
    if (historyPoints.size < 2) historyPoints.takeLast(10) else historyPoints.takeLast(40)
  }

  val values: List<Float> = remember(filteredPoints, selectedMetric) {
    filteredPoints.map { pt ->
      when (selectedMetric) {
        ChartMetricType.TEMPERATURE -> pt.safeTempC.toFloat()
        ChartMetricType.HUMIDITY -> pt.safeHumidity.toFloat()
        ChartMetricType.SOIL_MOISTURE -> pt.safeSoilAvg.toFloat()
      }
    }
  }

  val minVal = values.minOrNull() ?: 0f
  val maxVal = values.maxOrNull() ?: 100f
  val currentVal = values.lastOrNull() ?: 0f

  val activePoint = touchedIndex?.let { idx ->
    filteredPoints.getOrNull(idx)
  }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("telemetry_chart_card"),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Header: Title & Metric Selection Chips
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = metricColor.copy(alpha = 0.2f),
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.ShowChart,
                contentDescription = null,
                tint = metricColor,
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Column {
            Text(
              text = "Telemetry Trends",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "${selectedMetric.title} historical curve",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      // Metric Filter Chips
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        ChartMetricType.entries.forEach { metric ->
          FilterChip(
            selected = selectedMetric == metric,
            onClick = { selectedMetric = metric; touchedIndex = null },
            label = { Text(metric.title, fontSize = 11.sp) },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
          )
        }
      }

      // Hero Value Display
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          val displayVal = if (activePoint != null) {
            when (selectedMetric) {
              ChartMetricType.TEMPERATURE -> activePoint.tempC?.let { "%.1f".format(it) } ?: "--"
              ChartMetricType.HUMIDITY -> activePoint.humidity?.let { "%.1f".format(it) } ?: "--"
              ChartMetricType.SOIL_MOISTURE -> activePoint.soilAvg?.toString() ?: "--"
            }
          } else {
            "%.1f".format(currentVal)
          }

          val timeLabel = if (activePoint != null) {
            SimpleDateFormat("MMM dd HH:mm", Locale.getDefault()).format(Date(activePoint.timestampMs))
          } else {
            "Latest Reading"
          }

          Row(verticalAlignment = Alignment.Bottom) {
            Text(
              text = displayVal,
              fontSize = 32.sp,
              fontWeight = FontWeight.Black,
              color = metricColor
            )
            Text(
              text = selectedMetric.unit,
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = metricColor,
              modifier = Modifier.padding(bottom = 4.dp, start = 2.dp)
            )
          }
          Text(text = timeLabel, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }

      // Canvas Trend Curve
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(160.dp)
          .clip(RoundedCornerShape(18.dp))
          .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
          .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(18.dp))
          .pointerInput(filteredPoints) {
            detectTapGestures(
              onTap = { offset ->
                if (filteredPoints.isNotEmpty()) {
                  val frac = (offset.x / size.width).coerceIn(0f, 1f)
                  touchedIndex = (frac * (filteredPoints.size - 1)).toInt()
                }
              }
            )
          }
      ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 14.dp)) {
          if (values.size < 2) return@Canvas
          val w = size.width
          val h = size.height
          val stepX = w / (values.size - 1)
          val range = (maxVal - minVal).coerceAtLeast(1f)

          val path = Path()
          values.forEachIndexed { idx, v ->
            val norm = (v - minVal) / range
            val x = idx * stepX
            val y = h * (1f - norm.coerceIn(0.05f, 0.95f))
            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
          }

          drawPath(
            path = path,
            color = metricColor,
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
          )
        }
      }
    }
  }
}
