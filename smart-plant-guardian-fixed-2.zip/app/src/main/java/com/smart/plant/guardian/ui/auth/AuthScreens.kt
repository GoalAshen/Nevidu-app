package com.smart.plant.guardian.ui.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smart.plant.guardian.data.model.UserProfile
import com.smart.plant.guardian.data.model.UserRole
import com.smart.plant.guardian.data.model.UserStatus

@Composable
fun AuthModalDialog(
  isOpen: Boolean,
  onDismiss: () -> Unit,
  onSignIn: (email: String, pass: String, onResult: (Boolean, String?) -> Unit) -> Unit,
  onRegister: (email: String, pass: String, displayName: String, onResult: (Boolean, String?) -> Unit) -> Unit
) {
  if (!isOpen) return

  var isRegisterMode by remember { mutableStateOf(false) }
  var email by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var displayName by remember { mutableStateOf("") }
  var passwordVisible by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var isLoading by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    shape = RoundedCornerShape(28.dp),
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Surface(
          shape = CircleShape,
          color = MaterialTheme.colorScheme.primaryContainer,
          modifier = Modifier.size(40.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (isRegisterMode) Icons.Default.PersonAdd else Icons.Default.Lock,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onPrimaryContainer,
              modifier = Modifier.size(22.dp)
            )
          }
        }
        Column {
          Text(
            text = if (isRegisterMode) "Create Account" else "Account Sign-In",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Smart Plant Guardian Security",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        errorMessage?.let { err ->
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.errorContainer,
            modifier = Modifier.fillMaxWidth().testTag("auth_error_banner")
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(imageVector = Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
              Text(text = err, fontSize = 12.sp, color = MaterialTheme.colorScheme.onErrorContainer)
            }
          }
        }

        if (isRegisterMode) {
          OutlinedTextField(
            value = displayName,
            onValueChange = { displayName = it },
            label = { Text("Display Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("auth_display_name_input"),
            shape = RoundedCornerShape(14.dp)
          )
        }

        OutlinedTextField(
          value = email,
          onValueChange = { email = it },
          label = { Text("Email Address") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("auth_email_input"),
          shape = RoundedCornerShape(14.dp)
        )

        OutlinedTextField(
          value = password,
          onValueChange = { password = it },
          label = { Text("Password") },
          singleLine = true,
          visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
          trailingIcon = {
            IconButton(onClick = { passwordVisible = !passwordVisible }) {
              Icon(
                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                contentDescription = "Toggle password"
              )
            }
          },
          modifier = Modifier.fillMaxWidth().testTag("auth_password_input"),
          shape = RoundedCornerShape(14.dp)
        )

        TextButton(
          onClick = {
            isRegisterMode = !isRegisterMode
            errorMessage = null
          },
          modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
          Text(
            text = if (isRegisterMode) "Already have an account? Sign In" else "Don't have an account? Register as Viewer",
            fontSize = 12.sp
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (email.isBlank() || password.isBlank()) {
            errorMessage = "Please enter both email and password."
            return@Button
          }
          isLoading = true
          errorMessage = null
          if (isRegisterMode) {
            onRegister(email, password, displayName) { success, err ->
              isLoading = false
              if (success) onDismiss() else errorMessage = err
            }
          } else {
            onSignIn(email, password) { success, err ->
              isLoading = false
              if (success) onDismiss() else errorMessage = err
            }
          }
        },
        enabled = !isLoading,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.testTag("auth_submit_button")
      ) {
        if (isLoading) {
          CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
        } else {
          Text(if (isRegisterMode) "Register" else "Sign In")
        }
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}

@Composable
fun PendingApprovalNotice(
  userProfile: UserProfile,
  onRefresh: () -> Unit,
  onSignOut: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    border = CardDefaults.outlinedCardBorder(),
    modifier = Modifier.fillMaxWidth().padding(16.dp).testTag("pending_approval_notice")
  ) {
    Column(
      modifier = Modifier.padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.secondaryContainer,
        modifier = Modifier.size(56.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.Default.HourglassEmpty,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.size(32.dp)
          )
        }
      }
      Text(
        text = "Waiting for Admin Approval",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = "Hello, ${userProfile.displayName}! Your account (${userProfile.email}) has been registered with role 'Viewer'. An administrator must activate your account before you can view sensor telemetry.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(onClick = onSignOut, shape = RoundedCornerShape(12.dp)) {
          Text("Sign Out")
        }
        Button(onClick = onRefresh, shape = RoundedCornerShape(12.dp)) {
          Text("Check Status")
        }
      }
    }
  }
}

@Composable
fun BlockedUserNotice(
  userProfile: UserProfile,
  onSignOut: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
    border = CardDefaults.outlinedCardBorder(),
    modifier = Modifier.fillMaxWidth().padding(16.dp).testTag("blocked_user_notice")
  ) {
    Column(
      modifier = Modifier.padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.error,
        modifier = Modifier.size(56.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.Default.Block,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onError,
            modifier = Modifier.size(32.dp)
          )
        }
      }
      Text(
        text = "Access Disabled",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onErrorContainer
      )
      Text(
        text = "Your account (${userProfile.email}) has been suspended or blocked by an administrator. Please contact your system administrator.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onErrorContainer
      )
      Button(
        onClick = onSignOut,
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
        shape = RoundedCornerShape(12.dp)
      ) {
        Text("Sign Out", color = MaterialTheme.colorScheme.onError)
      }
    }
  }
}
