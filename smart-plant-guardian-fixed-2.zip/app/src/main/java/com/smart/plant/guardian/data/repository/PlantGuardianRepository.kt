package com.smart.plant.guardian.data.repository

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.smart.plant.guardian.data.model.*
import com.smart.plant.guardian.data.remote.FirebasePrefs
import com.smart.plant.guardian.data.remote.FirebaseSettings
import com.smart.plant.guardian.util.NotificationHelper
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.UUID
import kotlin.random.Random

class PlantGuardianRepository(
  private val coroutineScope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
) {
  private var appContext: Context? = null

  // Firebase Configuration & State
  private val _firebaseConfig = MutableStateFlow(FirebaseSettings())
  val firebaseConfig: StateFlow<FirebaseSettings> = _firebaseConfig.asStateFlow()

  private val _connectionError = MutableStateFlow<String?>(null)
  val connectionError: StateFlow<String?> = _connectionError.asStateFlow()

  private val _commandFeedbackError = MutableStateFlow<String?>(null)
  val commandFeedbackError: StateFlow<String?> = _commandFeedbackError.asStateFlow()

  // User Authentication & Roles
  private val _currentUserProfile = MutableStateFlow<UserProfile?>(null)
  val currentUserProfile: StateFlow<UserProfile?> = _currentUserProfile.asStateFlow()

  private val _allUsers = MutableStateFlow<List<UserProfile>>(emptyList())
  val allUsers: StateFlow<List<UserProfile>> = _allUsers.asStateFlow()

  private val _auditLogs = MutableStateFlow<List<AuditEntry>>(emptyList())
  val auditLogs: StateFlow<List<AuditEntry>> = _auditLogs.asStateFlow()

  // Devices & Telemetry State
  private val _devices = MutableStateFlow<List<Device>>(
    listOf(Device("device1", "Plant Node 1", "My garden", 0.0, 0.0))
  )
  val devices: StateFlow<List<Device>> = _devices.asStateFlow()

  private val _selectedDeviceId = MutableStateFlow("device1")
  val selectedDeviceId: StateFlow<String> = _selectedDeviceId.asStateFlow()

  private val _sensorDataMap = MutableStateFlow<Map<String, SensorData>>(emptyMap())
  val sensorDataMap: StateFlow<Map<String, SensorData>> = _sensorDataMap.asStateFlow()

  private val _relayStateMap = MutableStateFlow<Map<String, RelayState>>(
    mapOf(
      "device1" to RelayState(isPumpOn = false, mode = RelayMode.AUTO)
    )
  )
  val relayStateMap: StateFlow<Map<String, RelayState>> = _relayStateMap.asStateFlow()

  private val _thresholdsMap = MutableStateFlow<Map<String, EcoThresholds>>(
    mapOf(
      "device1" to EcoThresholds()
    )
  )
  val thresholdsMap: StateFlow<Map<String, EcoThresholds>> = _thresholdsMap.asStateFlow()

  private val _hardwareControlsMap = MutableStateFlow<Map<String, HardwareControls>>(
    mapOf(
      "device1" to HardwareControls()
    )
  )
  val hardwareControlsMap: StateFlow<Map<String, HardwareControls>> = _hardwareControlsMap.asStateFlow()

  private val _scheduleMap = MutableStateFlow<Map<String, DailySchedule>>(
    mapOf(
      "device1" to DailySchedule()
    )
  )
  val scheduleMap: StateFlow<Map<String, DailySchedule>> = _scheduleMap.asStateFlow()

  private val _telemetryHistoryMap = MutableStateFlow<Map<String, List<TelemetryPoint>>>(emptyMap())
  val telemetryHistoryMap: StateFlow<Map<String, List<TelemetryPoint>>> = _telemetryHistoryMap.asStateFlow()

  private val _alerts = MutableStateFlow<List<SystemAlert>>(emptyList())
  val alerts: StateFlow<List<SystemAlert>> = _alerts.asStateFlow()

  private val _systemNotificationsEnabled = MutableStateFlow(true)
  val systemNotificationsEnabled: StateFlow<Boolean> = _systemNotificationsEnabled.asStateFlow()

  // Realtime Database & Clock Offset Listeners
  private var activeSensorsRef: DatabaseReference? = null
  private var activeSensorsListener: ValueEventListener? = null
  private var activeStatusRef: DatabaseReference? = null
  private var activeStatusListener: ValueEventListener? = null
  private var activeHistoryRef: Query? = null
  private var activeHistoryListener: ValueEventListener? = null
  private var offsetRef: DatabaseReference? = null
  private var offsetListener: ValueEventListener? = null
  private var serverTimeOffsetMs: Long = 0L

  // Command Feedback Watchdogs (10-second timeout)
  private var pendingPumpCommand: Boolean? = null
  private var pendingPumpJob: Job? = null
  private var pendingModeCommand: RelayMode? = null
  private var pendingModeJob: Job? = null

  // Periodic alert / offline watchdog
  private var watchdogJob: Job? = null
  private val lastAlertNotifiedTimes = mutableMapOf<String, Long>()

  fun setApplicationContext(context: Context) {
    if (appContext == null) {
      appContext = context.applicationContext
      val saved = FirebasePrefs.load(context)
      _firebaseConfig.value = saved

      startAlertWatchdog()
      if (saved.databaseUrl.isNotBlank()) {
        authenticateAndConnectFirebase(saved)
      }
    }
  }

  fun dismissConnectionError() {
    _connectionError.value = null
  }

  fun dismissCommandFeedbackError() {
    _commandFeedbackError.value = null
  }

  fun getSynchronizedServerTime(): Long = System.currentTimeMillis() + serverTimeOffsetMs

  fun selectDevice(deviceId: String) {
    _selectedDeviceId.value = deviceId
      attachFirebaseListeners(deviceId)
  }

  // =========================================================================
  // AUTHENTICATION & ROLE MANAGEMENT
  // =========================================================================

  fun updateFirebaseConfig(settings: FirebaseSettings) {
    _firebaseConfig.value = settings
    appContext?.let { FirebasePrefs.save(it, settings) }

    authenticateAndConnectFirebase(settings)
  }

  fun registerAccount(email: String, pass: String, displayName: String, onResult: (Boolean, String?) -> Unit) {
    val auth = getAuth(_firebaseConfig.value)
    if (auth == null) {
      onResult(false, "Firebase Auth is not initialized. Please verify App ID & configuration.")
      return
    }

    auth.createUserWithEmailAndPassword(email.trim(), pass.trim())
      .addOnSuccessListener { res ->
        val user = res.user
        if (user != null) {
          val profile = UserProfile(
            uid = user.uid,
            email = email.trim(),
            displayName = displayName.trim().ifBlank { email.substringBefore("@") },
            role = UserRole.VIEWER,
            status = UserStatus.PENDING,
            createdAt = System.currentTimeMillis(),
            lastLoginMs = System.currentTimeMillis()
          )
          _currentUserProfile.value = profile
          saveUserProfileToFirebase(profile)
          recordAudit(profile.uid, profile.email, "ACCOUNT_REGISTER", "New user registered as pending viewer")
          onResult(true, null)
        } else {
          onResult(false, "User creation failed: Empty user instance.")
        }
      }
      .addOnFailureListener { e ->
        onResult(false, e.localizedMessage ?: "Registration failed.")
      }
  }

  fun signIn(email: String, pass: String, onResult: (Boolean, String?) -> Unit) {
    val cleanEmail = email.trim()
    val cleanPass = pass.trim()

    val auth = getAuth(_firebaseConfig.value)
    if (auth == null) {
      onResult(false, "Firebase Auth not available. Verify settings.")
      return
    }

    auth.signInWithEmailAndPassword(cleanEmail, cleanPass)
      .addOnSuccessListener { res ->
        val uid = res.user?.uid ?: ""
        fetchUserProfile(uid, cleanEmail)
        _connectionError.value = null
        _firebaseConfig.update { it.copy(ownerEmail = cleanEmail, authPassword = cleanPass) }
        appContext?.let { FirebasePrefs.save(it, _firebaseConfig.value) }
        attachFirebaseListeners(_selectedDeviceId.value)
        recordAudit(uid, cleanEmail, "USER_LOGIN", "User signed in successfully")
        onResult(true, null)
      }
      .addOnFailureListener { e ->
        val msg = when (e) {
          is com.google.firebase.auth.FirebaseAuthInvalidCredentialsException -> "Incorrect email or password."
          is com.google.firebase.auth.FirebaseAuthInvalidUserException -> "No account found with this email."
          is com.google.firebase.FirebaseNetworkException -> "No internet connection. Please verify network."
          else -> e.localizedMessage ?: "Authentication failed."
        }
        _connectionError.value = msg
        onResult(false, msg)
      }
  }

  fun signOut() {
    try {
      getAuth(_firebaseConfig.value)?.signOut()
    } catch (_: Exception) {}
    _currentUserProfile.value = null
    _connectionError.value = null
  }

  fun refreshUserProfile() {
    val p = _currentUserProfile.value ?: return
    fetchUserProfile(p.uid, p.email)
  }

  private fun fetchUserProfile(uid: String, fallbackEmail: String) {
    val db = getDatabase(_firebaseConfig.value) ?: return
    db.getReference("users/$uid").addListenerForSingleValueEvent(object : ValueEventListener {
      override fun onDataChange(snapshot: DataSnapshot) {
        if (snapshot.exists()) {
          val email = snapshot.child("email").getValue(String::class.java) ?: fallbackEmail
          val name = snapshot.child("displayName").getValue(String::class.java) ?: email.substringBefore("@")
          val roleStr = snapshot.child("role").getValue(String::class.java)
          val statusStr = snapshot.child("status").getValue(String::class.java)
          val created = snapshot.child("createdAt").getValue(Long::class.java) ?: System.currentTimeMillis()

          val profile = UserProfile(
            uid = uid,
            email = email,
            displayName = name,
            role = UserRole.fromString(roleStr),
            status = UserStatus.fromString(statusStr),
            createdAt = created,
            lastLoginMs = System.currentTimeMillis()
          )
          _currentUserProfile.value = profile
        } else {
          // If profile does not exist yet (e.g. first admin)
          val profile = UserProfile(
            uid = uid,
            email = fallbackEmail,
            displayName = fallbackEmail.substringBefore("@"),
            role = UserRole.VIEWER,
            status = UserStatus.PENDING
          )
          _currentUserProfile.value = profile
          saveUserProfileToFirebase(profile)
        }
      }
      override fun onCancelled(error: DatabaseError) {}
    })
  }

  private fun saveUserProfileToFirebase(profile: UserProfile) {
    val db = getDatabase(_firebaseConfig.value) ?: return
    val map = mapOf(
      "email" to profile.email,
      "displayName" to profile.displayName,
      "role" to profile.role.roleName,
      "status" to profile.status.statusName,
      "createdAt" to profile.createdAt,
      "lastLoginMs" to profile.lastLoginMs
    )
    db.getReference("users/${profile.uid}").updateChildren(map)
  }

  // =========================================================================
  // ADMIN PANEL OPERATIONS
  // =========================================================================

  fun approveUser(uid: String) {
    updateUserStatus(uid, UserStatus.ACTIVE)
    recordAudit(uid, "", "ADMIN_USER_APPROVE", "Approved user $uid")
  }

  fun updateUserRole(uid: String, newRole: UserRole) {
    _allUsers.update { list ->
      list.map { if (it.uid == uid) it.copy(role = newRole) else it }
    }
    if (_currentUserProfile.value?.uid == uid) {
      _currentUserProfile.update { it?.copy(role = newRole) }
    }
      getDatabase(_firebaseConfig.value)?.getReference("users/$uid/role")?.setValue(newRole.roleName)
    recordAudit(uid, "", "ADMIN_ROLE_CHANGE", "Changed role of $uid to ${newRole.roleName}")
  }

  fun updateUserStatus(uid: String, newStatus: UserStatus) {
    _allUsers.update { list ->
      list.map { if (it.uid == uid) it.copy(status = newStatus) else it }
    }
    if (_currentUserProfile.value?.uid == uid) {
      _currentUserProfile.update { it?.copy(status = newStatus) }
    }
      getDatabase(_firebaseConfig.value)?.getReference("users/$uid/status")?.setValue(newStatus.statusName)
    recordAudit(uid, "", "ADMIN_STATUS_CHANGE", "Changed status of $uid to ${newStatus.statusName}")
  }

  fun assignDeviceMember(deviceId: String, uid: String, grantAccess: Boolean) {
    _devices.update { list ->
      list.map { dev ->
        if (dev.id == deviceId) {
          val updated = if (grantAccess) (dev.memberUids + uid).distinct() else dev.memberUids - uid
          dev.copy(memberUids = updated)
        } else dev
      }
    }
      val ref = getDatabase(_firebaseConfig.value)?.getReference("devices/$deviceId/members/$uid")
      if (grantAccess) ref?.setValue(true) else ref?.removeValue()
    recordAudit(uid, "", "ADMIN_DEVICE_MEMBER", "${if (grantAccess) "Granted" else "Revoked"} access to $deviceId for $uid")
  }

  fun applyGlobalThresholdsToAllDevices(thresholds: EcoThresholds) {
    _devices.value.forEach { dev ->
      updateThresholds(dev.id, thresholds)
    }
    recordAudit("", "", "ADMIN_GLOBAL_THRESHOLDS", "Applied global thresholds across all devices")
  }

  fun emergencyTurnAllPumpsOff() {
    _devices.value.forEach { dev ->
      setPumpState(dev.id, false)
    }
    recordAudit("", "", "EMERGENCY_STOP_ALL_PUMPS", "Emergency shutdown executed: All pumps OFF")
  }

  fun emergencyForceManualModeAll() {
    _devices.value.forEach { dev ->
      setRelayMode(dev.id, RelayMode.MANUAL)
    }
    recordAudit("", "", "EMERGENCY_FORCE_MANUAL", "Emergency override executed: All devices forced to MANUAL mode")
  }

  fun recordAudit(targetUid: String, targetEmail: String, action: String, details: String) {
    val actor = _currentUserProfile.value
    val entry = AuditEntry(
      id = UUID.randomUUID().toString(),
      uid = actor?.uid ?: targetUid,
      email = actor?.email ?: targetEmail,
      action = action,
      deviceId = _selectedDeviceId.value,
      timestampMs = System.currentTimeMillis()
    )
    _auditLogs.update { (listOf(entry) + it).take(200) }

      val db = getDatabase(_firebaseConfig.value) ?: return
      val map = mapOf(
        "uid" to entry.uid,
        "email" to entry.email,
        "action" to entry.action,
        "deviceId" to entry.deviceId,
        "timestampMs" to entry.timestampMs,
        "details" to details
      )
      db.getReference("audit").push().setValue(map)
  }

  // =========================================================================
  // HARDWARE COMMANDS & RELAY EXECUTION (Role-Gated & Audited)
  // =========================================================================

  fun togglePump(deviceId: String, turnOn: Boolean) {
    val user = _currentUserProfile.value
    if (user?.role == UserRole.VIEWER) {
      _connectionError.value = "Access Denied: Viewers cannot execute pump commands."
      return
    }
    setPumpState(deviceId, turnOn)
    recordAudit(deviceId, "", "PUMP_TOGGLE", "Pump set to ${if (turnOn) "ON" else "OFF"}")
  }

  private fun setPumpState(deviceId: String, turnOn: Boolean) {
    _relayStateMap.update { current ->
      val prev = current[deviceId] ?: RelayState()
      current + (deviceId to prev.copy(isPumpOn = turnOn, lastToggledEpochMs = System.currentTimeMillis()))
    }

      pendingPumpCommand = turnOn
      pendingPumpJob?.cancel()
      pendingPumpJob = coroutineScope.launch {
        delay(10_000L)
        if (pendingPumpCommand != null) {
          _commandFeedbackError.value = "Device did not respond: Pump command unconfirmed."
          pendingPumpCommand = null
        }
      }
      writeCommandsToFirebase(deviceId, mapOf("pump" to turnOn))
  }

  fun setRelayMode(deviceId: String, mode: RelayMode) {
    val user = _currentUserProfile.value
    if (user?.role == UserRole.VIEWER) {
      _connectionError.value = "Access Denied: Viewers cannot change operating modes."
      return
    }

    _relayStateMap.update { current ->
      val prev = current[deviceId] ?: RelayState()
      current + (deviceId to prev.copy(mode = mode))
    }

      pendingModeCommand = mode
      pendingModeJob?.cancel()
      pendingModeJob = coroutineScope.launch {
        delay(10_000L)
        if (pendingModeCommand != null) {
          _commandFeedbackError.value = "Device did not respond: Mode switch unconfirmed."
          pendingModeCommand = null
        }
      }
      writeCommandsToFirebase(deviceId, mapOf("mode" to mode.name))
    recordAudit(deviceId, "", "MODE_CHANGE", "Relay mode set to ${mode.name}")
  }

  fun toggleDevicePower(deviceId: String, powerOn: Boolean) {
    val user = _currentUserProfile.value
    if (user?.role == UserRole.VIEWER) {
      _connectionError.value = "Access Denied: Viewers cannot toggle hardware power."
      return
    }

    _devices.update { list ->
      list.map { if (it.id == deviceId) it.copy(isPoweredOn = powerOn) else it }
    }
    writeCommandsToFirebase(deviceId, mapOf("power" to powerOn))
    recordAudit(deviceId, "", "DEVICE_POWER", "Device power set to $powerOn")
  }

  fun toggleBuzzer(deviceId: String, active: Boolean) {
    if (_currentUserProfile.value?.role == UserRole.VIEWER) return
    _hardwareControlsMap.update { current ->
      val prev = current[deviceId] ?: HardwareControls()
      current + (deviceId to prev.copy(buzzerActive = active))
    }
    writeCommandsToFirebase(deviceId, mapOf("buzzer" to active))
    recordAudit(deviceId, "", "BUZZER_TOGGLE", "Buzzer set to $active")
  }

  fun toggleSpeaker(deviceId: String, active: Boolean) {
    if (_currentUserProfile.value?.role == UserRole.VIEWER) return
    _hardwareControlsMap.update { current ->
      val prev = current[deviceId] ?: HardwareControls()
      current + (deviceId to prev.copy(speakerAlertActive = active))
    }
    writeCommandsToFirebase(deviceId, mapOf("speaker" to active))
    recordAudit(deviceId, "", "SPEAKER_TOGGLE", "Speaker siren set to $active")
  }

  fun toggleLed(deviceId: String, color: String, turnOn: Boolean) {
    if (_currentUserProfile.value?.role == UserRole.VIEWER) return
    _hardwareControlsMap.update { current ->
      val prev = current[deviceId] ?: HardwareControls()
      val updated = when (color.lowercase()) {
        "red" -> prev.copy(ledRed = turnOn)
        "blue" -> prev.copy(ledBlue = turnOn)
        "green" -> prev.copy(ledGreen = turnOn)
        "yellow" -> prev.copy(ledYellow = turnOn)
        else -> prev
      }
      current + (deviceId to updated)
    }
    val key = when (color.lowercase()) {
      "red" -> "ledRed"
      "blue" -> "ledBlue"
      "green" -> "ledGreen"
      "yellow" -> "ledYellow"
      else -> "ledGreen"
    }
    writeCommandsToFirebase(deviceId, mapOf(key to turnOn))
  }

  fun updateThresholds(deviceId: String, thresholds: EcoThresholds) {
    if (_currentUserProfile.value?.role == UserRole.VIEWER) return
    _thresholdsMap.update { current ->
      current + (deviceId to thresholds)
    }
    val map = mapOf(
      "soilDryPercent" to thresholds.soilDryPercent,
      "soilTargetPercent" to thresholds.soilTargetPercent,
      "highTempAlertThresholdC" to thresholds.highTempAlertThresholdC,
      "lowBatteryAlertPercent" to thresholds.lowBatteryAlertPercent,
      "maxPumpRunTimeMinutes" to thresholds.maxPumpRunTimeMinutes
    )
    writeSettingsToFirebase(deviceId, map)
    recordAudit(deviceId, "", "SETTINGS_UPDATE", "Updated sensor thresholds")
  }

  fun updateDailySchedule(deviceId: String, schedule: DailySchedule) {
    if (_currentUserProfile.value?.role == UserRole.VIEWER) return
    _scheduleMap.update { current ->
      current + (deviceId to schedule)
    }
    val map = mapOf(
      "schedule" to mapOf(
        "enabled" to schedule.enabled,
        "startHour" to schedule.startHour,
        "startMinute" to schedule.startMinute,
        "durationMinutes" to schedule.durationMinutes,
        "activeDays" to schedule.activeDays.toList()
      )
    )
    writeSettingsToFirebase(deviceId, map)
    recordAudit(deviceId, "", "SCHEDULE_UPDATE", "Updated irrigation schedule")
  }

  fun toggleRainSensor(deviceId: String) {
    _sensorDataMap.update { current ->
      val sensor = current[deviceId] ?: return@update current
      val newRainState = !(sensor.isRaining ?: false)
      current + (deviceId to sensor.copy(isRaining = newRainState))
    }
  }

  fun addDevice(id: String, name: String, location: String, lat: Double = 37.7749, lng: Double = -122.4194) {
    val cleanId = id.trim().ifBlank { "NODE-" + UUID.randomUUID().toString().take(4).uppercase() }
    val cleanName = name.trim().ifBlank { cleanId }
    val cleanLocation = location.trim().ifBlank { "Custom Canopy" }

    val newDevice = Device(
      id = cleanId,
      name = cleanName,
      locationName = cleanLocation,
      latitude = lat,
      longitude = lng
    )

    _devices.update { list ->
      if (list.any { it.id == cleanId }) {
        list.map { if (it.id == cleanId) newDevice else it }
      } else {
        list + newDevice
      }
    }

    _relayStateMap.update { it + (cleanId to RelayState(isPumpOn = false, mode = RelayMode.AUTO)) }
    _thresholdsMap.update { it + (cleanId to EcoThresholds()) }
    _hardwareControlsMap.update { it + (cleanId to HardwareControls()) }
    _scheduleMap.update { it + (cleanId to DailySchedule()) }
    selectDevice(cleanId)
    recordAudit(cleanId, "", "DEVICE_ADD", "Registered node $cleanId ($cleanName)")
  }

  fun removeDevice(deviceId: String) {
    _devices.update { list -> list.filter { it.id != deviceId } }
    if (_selectedDeviceId.value == deviceId) {
      _selectedDeviceId.value = _devices.value.firstOrNull()?.id ?: ""
    }
    recordAudit(deviceId, "", "DEVICE_REMOVE", "Removed node $deviceId")
  }

  fun updateDeviceLocation(deviceId: String, lat: Double, lng: Double, location: String) {
    _devices.update { list ->
      list.map { if (it.id == deviceId) it.copy(latitude = lat, longitude = lng, locationName = location) else it }
    }
    recordAudit(deviceId, "", "DEVICE_LOCATION_UPDATE", "Updated map coordinate for $deviceId")
  }

  fun toggleSystemNotifications(enabled: Boolean) {
    _systemNotificationsEnabled.value = enabled
  }

  fun dismissAlert(alertId: String) {
    _alerts.update { list -> list.filter { it.id != alertId } }
  }

  fun clearEventLogs() {
    // Clear alerts / logs
    _alerts.value = emptyList()
  }

  // =========================================================================
  // FIREBASE INITIALIZATION & RTDB LISTENERS
  // =========================================================================

  private fun getOrInitFirebaseApp(settings: FirebaseSettings): FirebaseApp? {
    try {
      return FirebaseApp.getInstance()
    } catch (_: Exception) {}

    val ctx = appContext ?: return null
    if (settings.databaseUrl.isBlank()) return null

    val appId = settings.appId.trim()
    val apiKey = settings.apiKey.trim()
    val projectId = settings.projectId.trim()

    if (appId.isBlank()) {
      _connectionError.value = "Firebase App ID required (format: 1:123456789:android:abcdef)."
      return null
    }

    if (apiKey.isBlank()) {
      _connectionError.value = "Firebase API key required (Project settings > Web API Key)."
      return null
    }

    return try {
      val existingApps = FirebaseApp.getApps(ctx)
      if (existingApps.isNotEmpty()) {
        existingApps.first()
      } else {
        val options = FirebaseOptions.Builder()
          .setApplicationId(appId)
          .setApiKey(apiKey)
          .setDatabaseUrl(settings.databaseUrl.trim())
          .setProjectId(projectId.ifBlank { "smart-plant-guardian" })
          .build()
        FirebaseApp.initializeApp(ctx, options)
      }
    } catch (e: Exception) {
      _connectionError.value = "Firebase init failed: ${e.localizedMessage}"
      null
    }
  }

  private fun getDatabase(settings: FirebaseSettings): FirebaseDatabase? {
    val app = getOrInitFirebaseApp(settings)
    return try {
      if (app != null && settings.databaseUrl.isNotBlank()) {
        FirebaseDatabase.getInstance(app, settings.databaseUrl.trim())
      } else if (settings.databaseUrl.isNotBlank()) {
        FirebaseDatabase.getInstance(settings.databaseUrl.trim())
      } else {
        FirebaseDatabase.getInstance()
      }
    } catch (e: Exception) {
      _connectionError.value = "RTDB init error: ${e.localizedMessage}"
      null
    }
  }

  private fun getAuth(settings: FirebaseSettings): FirebaseAuth? {
    val app = getOrInitFirebaseApp(settings)
    return try {
      if (app != null) FirebaseAuth.getInstance(app) else FirebaseAuth.getInstance()
    } catch (e: Exception) {
      _connectionError.value = "Auth init error: ${e.localizedMessage}"
      null
    }
  }

  private fun authenticateAndConnectFirebase(settings: FirebaseSettings) {
    coroutineScope.launch {
      val auth = getAuth(settings)
      if (auth == null) {
        _connectionError.value = "Unable to initialize Firebase Auth. Check App ID & URL."
        return@launch
      }

      val email = settings.ownerEmail.trim()
      val password = settings.authPassword.trim()

      if (email.isNotBlank() && password.isNotBlank()) {
        try {
          auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { res ->
              _connectionError.value = null
              appContext?.let { FirebasePrefs.save(it, _firebaseConfig.value) }
              res.user?.let { fetchUserProfile(it.uid, email) }
              attachFirebaseListeners(_selectedDeviceId.value)
            }
            .addOnFailureListener { e ->
              val errText = when (e) {
                is com.google.firebase.auth.FirebaseAuthInvalidCredentialsException -> "Incorrect email or password."
                is com.google.firebase.auth.FirebaseAuthInvalidUserException -> "User account '$email' not found."
                is com.google.firebase.FirebaseNetworkException -> "No internet connection. Please verify network."
                else -> e.localizedMessage ?: "Sign-in error."
              }
              _connectionError.value = errText
            }
        } catch (e: Exception) {
          _connectionError.value = "Authentication error: ${e.localizedMessage}"
        }
      } else {
        _connectionError.value = null
        appContext?.let { FirebasePrefs.save(it, _firebaseConfig.value) }
        attachFirebaseListeners(_selectedDeviceId.value)
      }
    }
  }

  private fun attachFirebaseListeners(deviceId: String) {
    detachFirebaseListeners()
    val db = getDatabase(_firebaseConfig.value) ?: return

    try {
      // 0. Synchronize clock offset (.info/serverTimeOffset)
      val timeRef = db.getReference(".info/serverTimeOffset")
      offsetRef = timeRef
      val oListener = object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
          serverTimeOffsetMs = snapshot.getValue(Long::class.java) ?: 0L
        }
        override fun onCancelled(error: DatabaseError) {}
      }
      timeRef.addValueEventListener(oListener)
      offsetListener = oListener

      // 1. Read live /devices/{id}/sensors (NO fake defaults!)
      val sensorsRef = db.getReference("devices/$deviceId/sensors")
      activeSensorsRef = sensorsRef
      val sListener = object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
          if (!snapshot.exists()) return
          try {
            val temp = snapshot.child("temperatureC").getValue(Double::class.java)
              ?: snapshot.child("temperatureC").getValue(Long::class.java)?.toDouble()
            val hum = snapshot.child("humidityPercent").getValue(Double::class.java)
              ?: snapshot.child("humidityPercent").getValue(Long::class.java)?.toDouble()
            val z1 = snapshot.child("soilZone1").getValue(Long::class.java)?.toInt()
            val z2 = snapshot.child("soilZone2").getValue(Long::class.java)?.toInt()
            val z3 = snapshot.child("soilZone3").getValue(Long::class.java)?.toInt()
            val lightLuxVal = snapshot.child("lightLux").getValue(Long::class.java)?.toInt()
            val lightPctVal = snapshot.child("lightPercent").getValue(Long::class.java)?.toInt()
              ?: lightLuxVal?.let { (it / 1000).coerceIn(0, 100) }
            val raining = snapshot.child("isRaining").getValue(Boolean::class.java)
            val batteryPct = snapshot.child("batteryPercent").getValue(Long::class.java)?.toInt()
            val solar = if (snapshot.hasChild("solarCharging")) snapshot.child("solarCharging").getValue(Boolean::class.java) else null
            val lastSeen = snapshot.child("lastSeenEpochMs").getValue(Long::class.java)

            val updatedSensor = SensorData(
              temperatureC = temp,
              humidityPercent = hum,
              soilZone1 = z1,
              soilZone2 = z2,
              soilZone3 = z3,
              lightLux = lightLuxVal,
              lightPercent = lightPctVal,
              isRaining = raining,
              batteryPercent = batteryPct?.coerceIn(0, 100),
              solarCharging = solar,
              lastSeenEpochMs = lastSeen
            )

            _sensorDataMap.update { it + (deviceId to updatedSensor) }
            val now = getSynchronizedServerTime()
            evaluateAlerts(now)
          } catch (e: Exception) {
            _connectionError.value = "Error reading sensor telemetry: ${e.localizedMessage}"
          }
        }
        override fun onCancelled(error: DatabaseError) {
          _connectionError.value = "Sensors listener error: ${error.message}"
        }
      }
      sensorsRef.addValueEventListener(sListener)
      activeSensorsListener = sListener

      // 2. Read live /devices/{id}/status (Check command confirmation within 10s)
      val statusRef = db.getReference("devices/$deviceId/status")
      activeStatusRef = statusRef
      val statListener = object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
          if (!snapshot.exists()) return
          try {
            val pumpOn = snapshot.child("pumpOn").getValue(Boolean::class.java) ?: false
            val modeStr = snapshot.child("mode").getValue(String::class.java) ?: "AUTO"
            val activeRun = snapshot.child("activeRunSeconds").getValue(Long::class.java)?.toInt() ?: 0
            val mode = if (modeStr.equals("MANUAL", ignoreCase = true)) RelayMode.MANUAL else RelayMode.AUTO

            if (pendingPumpCommand != null && pendingPumpCommand == pumpOn) {
              pendingPumpJob?.cancel()
              pendingPumpCommand = null
              _commandFeedbackError.value = null
            }
            if (pendingModeCommand != null && pendingModeCommand == mode) {
              pendingModeJob?.cancel()
              pendingModeCommand = null
              _commandFeedbackError.value = null
            }

            _relayStateMap.update { current ->
              val prev = current[deviceId] ?: RelayState(isPumpOn = false, mode = mode)
              current + (deviceId to prev.copy(isPumpOn = pumpOn, mode = mode, activeRunSeconds = activeRun))
            }
          } catch (e: Exception) {
            _connectionError.value = "Error parsing status: ${e.localizedMessage}"
          }
        }
        override fun onCancelled(error: DatabaseError) {
          _connectionError.value = "Status listener error: ${error.message}"
        }
      }
      statusRef.addValueEventListener(statListener)
      activeStatusListener = statListener

      // 3. Read history /devices/{id}/history (READ ONLY, limitToLast 200)
      val historyQuery = db.getReference("devices/$deviceId/history").limitToLast(200)
      activeHistoryRef = historyQuery
      val histListener = object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
          if (!snapshot.exists()) return
          try {
            val points = mutableListOf<TelemetryPoint>()
            for (child in snapshot.children) {
              val ts = child.child("timestampMs").getValue(Long::class.java)
                ?: child.key?.toLongOrNull()
                ?: System.currentTimeMillis()
              val tempC = child.child("tempC").getValue(Double::class.java)
                ?: child.child("tempC").getValue(Long::class.java)?.toDouble()
              val hum = child.child("humidity").getValue(Double::class.java)
                ?: child.child("humidity").getValue(Long::class.java)?.toDouble()
              val sAvg = child.child("soilAvg").getValue(Long::class.java)?.toInt()
              val z1 = child.child("zone1").getValue(Long::class.java)?.toInt()
              val z2 = child.child("zone2").getValue(Long::class.java)?.toInt()
              val z3 = child.child("zone3").getValue(Long::class.java)?.toInt()
              val lightPct = child.child("lightPercent").getValue(Long::class.java)?.toInt()
              val lightLuxVal = child.child("lightLux").getValue(Long::class.java)?.toInt()
              val batt = child.child("batteryPercent").getValue(Long::class.java)?.toInt()

              points.add(
                TelemetryPoint(
                  timestampMs = ts,
                  tempC = tempC,
                  humidity = hum,
                  soilAvg = sAvg,
                  zone1 = z1,
                  zone2 = z2,
                  zone3 = z3,
                  lightPercent = lightPct,
                  lightLux = lightLuxVal,
                  batteryPercent = batt
                )
              )
            }
            if (points.isNotEmpty()) {
              _telemetryHistoryMap.update { it + (deviceId to points.sortedBy { p -> p.timestampMs }) }
            }
          } catch (_: Exception) {}
        }
        override fun onCancelled(error: DatabaseError) {}
      }
      historyQuery.addValueEventListener(histListener)
      activeHistoryListener = histListener

      // 4. Audit listener (For Admin activity log)
      val auditRef = db.getReference("audit").limitToLast(100)
      auditRef.addValueEventListener(object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
          if (!snapshot.exists()) return
          val list = mutableListOf<AuditEntry>()
          for (c in snapshot.children) {
            val uid = c.child("uid").getValue(String::class.java) ?: ""
            val email = c.child("email").getValue(String::class.java) ?: ""
            val act = c.child("action").getValue(String::class.java) ?: ""
            val dev = c.child("deviceId").getValue(String::class.java) ?: ""
            val ts = c.child("timestampMs").getValue(Long::class.java) ?: System.currentTimeMillis()
            list.add(AuditEntry(id = c.key ?: "", uid = uid, email = email, action = act, deviceId = dev, timestampMs = ts))
          }
          _auditLogs.value = list.sortedByDescending { it.timestampMs }
        }
        override fun onCancelled(error: DatabaseError) {}
      })

      // 5. Users listener (For Admin User management)
      val usersRef = db.getReference("users")
      usersRef.addValueEventListener(object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
          if (!snapshot.exists()) return
          val uList = mutableListOf<UserProfile>()
          for (c in snapshot.children) {
            val uid = c.key ?: ""
            val em = c.child("email").getValue(String::class.java) ?: ""
            val dn = c.child("displayName").getValue(String::class.java) ?: em.substringBefore("@")
            val r = c.child("role").getValue(String::class.java)
            val s = c.child("status").getValue(String::class.java)
            val ca = c.child("createdAt").getValue(Long::class.java) ?: System.currentTimeMillis()
            val ll = c.child("lastLoginMs").getValue(Long::class.java) ?: System.currentTimeMillis()
            uList.add(
              UserProfile(
                uid = uid,
                email = em,
                displayName = dn,
                role = UserRole.fromString(r),
                status = UserStatus.fromString(s),
                createdAt = ca,
                lastLoginMs = ll
              )
            )
          }
          _allUsers.value = uList
        }
        override fun onCancelled(error: DatabaseError) {}
      })

    } catch (e: Exception) {
      _connectionError.value = "Failed to attach RTDB listeners: ${e.localizedMessage}"
    }
  }

  private fun detachFirebaseListeners() {
    try {
      activeSensorsListener?.let { activeSensorsRef?.removeEventListener(it) }
      activeStatusListener?.let { activeStatusRef?.removeEventListener(it) }
      activeHistoryListener?.let { activeHistoryRef?.removeEventListener(it) }
      offsetListener?.let { offsetRef?.removeEventListener(it) }
    } catch (_: Exception) {}
    activeSensorsRef = null
    activeSensorsListener = null
    activeStatusRef = null
    activeStatusListener = null
    activeHistoryRef = null
    activeHistoryListener = null
    offsetRef = null
    offsetListener = null
  }

  private fun writeCommandsToFirebase(deviceId: String, updates: Map<String, Any>) {
    val db = getDatabase(_firebaseConfig.value) ?: return
    try {
      db.getReference("devices/$deviceId/commands").updateChildren(updates)
        .addOnFailureListener { e -> _connectionError.value = "Command write error: ${e.localizedMessage}" }
    } catch (e: Exception) {
      _connectionError.value = "Command send failed: ${e.localizedMessage}"
    }
  }

  private fun writeSettingsToFirebase(deviceId: String, settingsMap: Map<String, Any>) {
    val db = getDatabase(_firebaseConfig.value) ?: return
    try {
      db.getReference("devices/$deviceId/settings").updateChildren(settingsMap)
        .addOnFailureListener { e -> _connectionError.value = "Settings update error: ${e.localizedMessage}" }
    } catch (e: Exception) {
      _connectionError.value = "Settings write failed: ${e.localizedMessage}"
    }
  }

  // =========================================================================
  // FOREGROUND-SAFE LOCAL NOTIFICATIONS
  // =========================================================================

  private fun checkForegroundNotifications(
    deviceId: String,
    sensor: SensorData,
    thresholds: EcoThresholds,
    now: Long
  ) {
    val ctx = appContext ?: return
    if (!_systemNotificationsEnabled.value) return
    val cooldownMs = 3 * 60 * 1000L

    fun shouldNotify(key: String): Boolean {
      val last = lastAlertNotifiedTimes[key] ?: 0L
      if (now - last > cooldownMs) {
        lastAlertNotifiedTimes[key] = now
        return true
      }
      return false
    }

    // 1. Dry soil
    val isDry = (sensor.soilZone1 != null && sensor.soilZone1 < thresholds.soilDryPercent) ||
      (sensor.soilZone2 != null && sensor.soilZone2 < thresholds.soilDryPercent) ||
      (sensor.soilZone3 != null && sensor.soilZone3 < thresholds.soilDryPercent)
    if (isDry && shouldNotify("dry_$deviceId")) {
      NotificationHelper.sendAlertNotification(
        context = ctx,
        id = 1001,
        title = "Dry Soil Warning: $deviceId",
        message = "Moisture below ${thresholds.soilDryPercent}% threshold. Automated irrigation initiated.",
        alertType = AlertType.DRY_SOIL
      )
    }

    // 2. High temp
    if (sensor.temperatureC != null && sensor.temperatureC > thresholds.highTempAlertThresholdC && shouldNotify("temp_$deviceId")) {
      NotificationHelper.sendAlertNotification(
        context = ctx,
        id = 1002,
        title = "High Temperature: $deviceId",
        message = "Temperature reached ${sensor.temperatureC}°C (alert limit: ${thresholds.highTempAlertThresholdC}°C).",
        alertType = AlertType.HIGH_TEMP
      )
    }

    // 3. Rain
    if (sensor.isRaining == true && shouldNotify("rain_$deviceId")) {
      NotificationHelper.sendAlertNotification(
        context = ctx,
        id = 1003,
        title = "Rain Detected: $deviceId",
        message = "Natural precipitation active. Automated irrigation paused.",
        alertType = AlertType.RAIN
      )
    }

    // 4. Low battery
    if (sensor.batteryPercent != null && sensor.batteryPercent <= thresholds.lowBatteryAlertPercent && shouldNotify("batt_$deviceId")) {
      NotificationHelper.sendAlertNotification(
        context = ctx,
        id = 1004,
        title = "Low Battery: $deviceId",
        message = "Node battery is at ${sensor.batteryPercent}% (threshold: ${thresholds.lowBatteryAlertPercent}%).",
        alertType = AlertType.LOW_BATTERY
      )
    }

    // 5. Offline
    if (!sensor.isOnline(now) && shouldNotify("offline_$deviceId")) {
      val sec = sensor.secondsSinceLastSeen(now) ?: 60L
      NotificationHelper.sendAlertNotification(
        context = ctx,
        id = 1005,
        title = "Device Offline: $deviceId",
        message = "Heartbeat lost $sec seconds ago (threshold: 60s).",
        alertType = AlertType.DEVICE_OFFLINE
      )
    }
  }

  // =========================================================================
  // ALERT / OFFLINE WATCHDOG
  // =========================================================================

  private fun startAlertWatchdog() {
    stopAlertWatchdog()
    watchdogJob = coroutineScope.launch {
      while (isActive) {
        delay(5000L)
        val now = getSynchronizedServerTime()
        evaluateAlerts(now)
        val selectedSensor = _sensorDataMap.value[_selectedDeviceId.value]
        val selectedThresholds = _thresholdsMap.value[_selectedDeviceId.value] ?: EcoThresholds()
        if (selectedSensor != null) {
          checkForegroundNotifications(_selectedDeviceId.value, selectedSensor, selectedThresholds, now)
        }
      }
    }
  }

  private fun stopAlertWatchdog() {
    watchdogJob?.cancel()
    watchdogJob = null
  }

  private fun evaluateAlerts(now: Long) {
    val currentAlerts = mutableListOf<SystemAlert>()
    _devices.value.forEach { dev ->
      val devId = dev.id
      val devName = dev.name
      val sensor = _sensorDataMap.value[devId] ?: return@forEach
      val thresholds = _thresholdsMap.value[devId] ?: EcoThresholds()

      val isDry = (sensor.soilZone1 != null && sensor.soilZone1 < thresholds.soilDryPercent) ||
        (sensor.soilZone2 != null && sensor.soilZone2 < thresholds.soilDryPercent) ||
        (sensor.soilZone3 != null && sensor.soilZone3 < thresholds.soilDryPercent)

      if (isDry) {
        currentAlerts.add(
          SystemAlert(
            id = "alert-soil-$devId",
            type = AlertType.DRY_SOIL,
            title = "Moisture Deficit: $devName",
            message = "Soil moisture below ${thresholds.soilDryPercent}% threshold.",
            severity = AlertSeverity.WARNING,
            timestampMs = now,
            deviceId = devId
          )
        )
      }

      if (sensor.temperatureC != null && sensor.temperatureC > thresholds.highTempAlertThresholdC) {
        currentAlerts.add(
          SystemAlert(
            id = "alert-temp-$devId",
            type = AlertType.HIGH_TEMP,
            title = "High Temperature: $devName",
            message = "Canopy temperature reached ${sensor.temperatureC}°C.",
            severity = AlertSeverity.WARNING,
            timestampMs = now,
            deviceId = devId
          )
        )
      }

      if (sensor.isRaining == true) {
        currentAlerts.add(
          SystemAlert(
            id = "alert-rain-$devId",
            type = AlertType.RAIN,
            title = "Rain Detected: $devName",
            message = "Precipitation active. Automated irrigation paused.",
            severity = AlertSeverity.INFO,
            timestampMs = now,
            deviceId = devId
          )
        )
      }

      if (sensor.batteryPercent != null && sensor.batteryPercent <= thresholds.lowBatteryAlertPercent) {
        currentAlerts.add(
          SystemAlert(
            id = "alert-batt-$devId",
            type = AlertType.LOW_BATTERY,
            title = "Low Battery: $devName",
            message = "Capacity is ${sensor.batteryPercent}% (threshold: ${thresholds.lowBatteryAlertPercent}%).",
            severity = AlertSeverity.WARNING,
            timestampMs = now,
            deviceId = devId
          )
        )
      }

      if (!sensor.isOnline(now)) {
        val sec = sensor.secondsSinceLastSeen(now) ?: 60L
        currentAlerts.add(
          SystemAlert(
            id = "alert-offline-$devId",
            type = AlertType.DEVICE_OFFLINE,
            title = "Node Offline: $devName",
            message = "Heartbeat lost $sec seconds ago (threshold: 60s).",
            severity = AlertSeverity.CRITICAL,
            timestampMs = now,
            deviceId = devId
          )
        )
      }
    }
    _alerts.value = currentAlerts
  }
}
