package com.smart.plant.guardian.pairing

import com.smart.plant.guardian.data.repository.PlantGuardianRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class DeviceRegistrationStep {
  IDLE,
  READY,
  SUCCESS,
  ERROR
}

class DirectDeviceManager(
  private val repository: PlantGuardianRepository
) {
  private val _step = MutableStateFlow(DeviceRegistrationStep.IDLE)
  val step: StateFlow<DeviceRegistrationStep> = _step.asStateFlow()

  private val _statusMessage = MutableStateFlow("")
  val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

  fun directAddDevice(id: String, name: String, location: String) {
    val cleanId = id.trim()
    if (cleanId.isBlank()) {
      _step.value = DeviceRegistrationStep.ERROR
      _statusMessage.value = "Device ID cannot be empty."
      return
    }

    repository.addDevice(id = cleanId, name = name, location = location)
    _step.value = DeviceRegistrationStep.SUCCESS
    _statusMessage.value = "Device $cleanId added. Listening to live telemetry on /devices/$cleanId."
  }

  fun reset() {
    _step.value = DeviceRegistrationStep.IDLE
    _statusMessage.value = ""
  }
}
