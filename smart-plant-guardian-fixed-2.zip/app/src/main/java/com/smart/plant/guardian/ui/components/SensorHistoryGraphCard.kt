package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smart.plant.guardian.data.model.TelemetryPoint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class HistorySensor(val label: String) {
  TEMPERATURE("Temp"),
  HUMIDITY("Humidity"),
  SOIL_AVG("Soil Avg"),
  SOIL_ZONE_1("Zone 1"),
  SOIL_ZONE_2("Zone 2"),
  SOIL_ZONE_3("Zone 3"),
  LIGHT("Light"),
  BATTERY("Battery")
}

@Composable
fun SensorHistoryGraphCard(
  historyPoints: List<TelemetryPoint>,
  modifier: Modifier = Modifier
) {
  var selectedWindowHours by remember { mutableIntStateOf(24) }
  var touchedIndex by remember { mutableStateOf<Int?>(null) }
  var showTable by remember { mutableStateOf(false) }

  // Available sensors with colors derived from theme
  val sensorColors = mapOf(
    HistorySensor.TEMPERATURE to MaterialTheme.colorScheme.primary,
    HistorySensor.HUMIDITY to MaterialTheme.colorScheme.tertiary,
    HistorySensor.SOIL_AVG to MaterialTheme.colorScheme.secondary,
    HistorySensor.SOIL_ZONE_1 to MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
    HistorySensor.SOIL_ZONE_2 to MaterialTheme.colorScheme.secondary.copy(alpha = 0.8f),
    HistorySensor.SOIL_ZONE_3 to MaterialTheme.colorScheme.tertiary.copy(alpha = 0.8f),
    HistorySensor.LIGHT to MaterialTheme.colorScheme.primaryContainer,
    HistorySensor.BATTERY to MaterialTheme.colorScheme.outline
  )

  var activeSensors by remember {
    mutableStateOf(setOf(HistorySensor.TEMPERATURE, HistorySensor.HUMIDITY, HistorySensor.SOIL_AVG))
  }

  val now = System.currentTimeMillis()
  val cutoff = now - (selectedWindowHours * 3600_000L)
  val filteredPoints = remember(historyPoints, selectedWindowHours) {
    val list = historyPoints.filter { it.timestampMs >= cutoff }
    if (list.size < 2) historyPoints.takeLast(15) else list
  }

  val activePoint = touchedIndex?.let { idx ->
    filteredPoints.getOrNull(idx)
  }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("sensor_history_graph_card"),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.ShowChart,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Column {
            Text(
              text = "Telemetry Analytics",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Read-only historical synchronization",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        IconButton(onClick = { showTable = !showTable }) {
          Icon(
            imageVector = if (showTable) Icons.Default.ShowChart else Icons.Default.TableChart,
            contentDescription = "Toggle View",
            tint = MaterialTheme.colorScheme.primary
          )
        }
      }

      // Time Filter Pills
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf(6 to "6h", 24 to "24h", 72 to "3d", 168 to "7d").forEach { (hrs, label) ->
          FilterChip(
            selected = selectedWindowHours == hrs,
            onClick = { selectedWindowHours = hrs; touchedIndex = null },
            label = { Text(label, fontSize = 11.sp) },
            shape = RoundedCornerShape(10.dp)
          )
        }
      }

      if (showTable) {
        // Table view of historical records (NO CSV export buttons)
        Surface(
          shape = RoundedCornerShape(18.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.fillMaxWidth().height(260.dp)
        ) {
          if (filteredPoints.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
              Text("No historical records available", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          } else {
            LazyColumn(
              modifier = Modifier.padding(12.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              items(filteredPoints.reversed().take(50)) { pt ->
                val timeStr = SimpleDateFormat("MMM dd HH:mm", Locale.getDefault()).format(Date(pt.timestampMs))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(text = timeStr, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(text = "${pt.tempC?.let { "%.1f".format(it) } ?: "--"}°C", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                  Text(text = "${pt.humidity?.let { "%.1f".format(it) } ?: "--"}%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                  Text(text = "${pt.soilAvg ?: "--"}% Soil", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                  Text(text = "${pt.batteryPercent ?: "--"}% Batt", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f), thickness = 0.5.dp)
              }
            }
          }
        }
      } else {
        // Multi-line Canvas Graph
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(18.dp))
            .pointerInput(filteredPoints) {
              detectTapGestures(
                onTap = { offset ->
                  if (filteredPoints.isNotEmpty()) {
                    val fraction = (offset.x / size.width).coerceIn(0f, 1f)
                    touchedIndex = (fraction * (filteredPoints.size - 1)).toInt()
                  }
                }
              )
            }
            .pointerInput(filteredPoints) {
              detectDragGestures { change, _ ->
                if (filteredPoints.isNotEmpty()) {
                  val fraction = (change.position.x / size.width).coerceIn(0f, 1f)
                  touchedIndex = (fraction * (filteredPoints.size - 1)).toInt()
                }
              }
            }
        ) {
          Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 14.dp)) {
            if (filteredPoints.size < 2) return@Canvas
            val w = size.width
            val h = size.height
            val stepX = w / (filteredPoints.size - 1)

            // Grid lines
            for (i in 0..4) {
              val y = h * (i.toFloat() / 4f)
              drawLine(
                color = Color.Gray.copy(alpha = 0.15f),
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f
              )
            }

            // Draw each active sensor line
            activeSensors.forEach { sensor ->
              val color = sensorColors[sensor] ?: Color.Green
              val path = Path()
              filteredPoints.forEachIndexed { idx, point ->
                val v = getPointSensorValue(point, sensor).first
                val norm = normalizeSensorValue(v, sensor)
                val x = idx * stepX
                val y = h * (1f - norm)
                if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
              }
              drawPath(
                path = path,
                color = color,
                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
              )
            }

            // Draw cursor if touched
            touchedIndex?.let { idx ->
              if (idx in filteredPoints.indices) {
                val touchX = idx * stepX
                drawLine(
                  color = Color.White.copy(alpha = 0.7f),
                  start = Offset(touchX, 0f),
                  end = Offset(touchX, h),
                  strokeWidth = 1.5.dp.toPx()
                )
              }
            }
          }
        }

        // Active point tooltip HUD
        activePoint?.let { pt ->
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              val dateStr = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault()).format(Date(pt.timestampMs))
              Text("Reading: $dateStr", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                activeSensors.forEach { s ->
                  val (v, u) = getPointSensorValue(pt, s)
                  val color = sensorColors[s] ?: MaterialTheme.colorScheme.primary
                  Column {
                    Text(text = s.label, fontSize = 9.sp, color = color, fontWeight = FontWeight.Bold)
                    Text(text = "${v.toInt()} $u", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = color)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

private fun getPointSensorValue(point: TelemetryPoint, sensor: HistorySensor): Pair<Double, String> {
  return when (sensor) {
    HistorySensor.TEMPERATURE -> point.safeTempC to "°C"
    HistorySensor.HUMIDITY -> point.safeHumidity to "%"
    HistorySensor.SOIL_AVG -> point.safeSoilAvg.toDouble() to "%"
    HistorySensor.SOIL_ZONE_1 -> point.safeZone1.toDouble() to "%"
    HistorySensor.SOIL_ZONE_2 -> point.safeZone2.toDouble() to "%"
    HistorySensor.SOIL_ZONE_3 -> point.safeZone3.toDouble() to "%"
    HistorySensor.LIGHT -> point.safeLightPercent.toDouble() to "%"
    HistorySensor.BATTERY -> point.safeBatteryPercent.toDouble() to "%"
  }
}

private fun normalizeSensorValue(value: Double, sensor: HistorySensor): Float {
  return when (sensor) {
    HistorySensor.TEMPERATURE -> ((value - 10.0) / 40.0).toFloat().coerceIn(0.05f, 0.95f)
    HistorySensor.HUMIDITY -> (value / 100.0).toFloat().coerceIn(0.05f, 0.95f)
    else -> (value / 100.0).toFloat().coerceIn(0.05f, 0.95f)
  }
}
