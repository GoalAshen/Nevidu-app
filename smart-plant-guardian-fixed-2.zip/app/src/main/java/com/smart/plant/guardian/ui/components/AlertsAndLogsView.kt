package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smart.plant.guardian.data.model.AlertSeverity
import com.smart.plant.guardian.data.model.SystemAlert

@Composable
fun AlertsAndLogsView(
  alerts: List<SystemAlert>,
  notificationsEnabled: Boolean,
  onToggleNotifications: (Boolean) -> Unit,
  onSendTestNotification: () -> Unit,
  onDismissAlert: (String) -> Unit,
  onClearLogs: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("alerts_and_logs_card"),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.errorContainer,
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.NotificationsActive,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Column {
            Text(
              text = "System Alerts & Notifications",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "${alerts.size} active environmental triggers",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      // Notification settings row
      Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Push Notifications", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("Smart Plant Guardian Alerts channel", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(
              onClick = onSendTestNotification,
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
              Text("Test", fontSize = 11.sp)
            }
            Switch(
              checked = notificationsEnabled,
              onCheckedChange = onToggleNotifications
            )
          }
        }
      }

      // Active Alerts List
      if (alerts.isEmpty()) {
        Surface(
          shape = RoundedCornerShape(18.dp),
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(
              text = "All systems optimal. No alerts active.",
              fontWeight = FontWeight.SemiBold,
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          alerts.forEach { alert ->
            val alertColor = when (alert.severity) {
              AlertSeverity.CRITICAL -> MaterialTheme.colorScheme.error
              AlertSeverity.WARNING -> MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
              AlertSeverity.INFO -> MaterialTheme.colorScheme.primary
            }

            Surface(
              shape = RoundedCornerShape(16.dp),
              color = alertColor.copy(alpha = 0.12f),
              border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(alertColor.copy(alpha = 0.5f))
              ),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = alertColor)
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = alert.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = alertColor)
                  Text(text = alert.message, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                  Text(text = "${alert.deviceId} • ${alert.formattedTime()}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { onDismissAlert(alert.id) }) {
                  Icon(Icons.Default.Close, contentDescription = "Dismiss Alert", modifier = Modifier.size(16.dp), tint = alertColor)
                }
              }
            }
          }

          TextButton(
            onClick = onClearLogs,
            modifier = Modifier.align(Alignment.End)
          ) {
            Text("Clear All Active Alerts", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
          }
        }
      }
    }
  }
}
