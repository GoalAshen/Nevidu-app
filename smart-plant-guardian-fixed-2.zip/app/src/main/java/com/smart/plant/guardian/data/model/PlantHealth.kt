package com.smart.plant.guardian.data.model

enum class PlantHealthTier {
  THRIVING,
  HEALTHY,
  ATTENTION_NEEDED,
  STRESSED
}

data class PlantHealthAnalysis(
  val overallScore: Int, // 0 - 100
  val tier: PlantHealthTier,
  val vitalitySummary: String,
  val moistureHealthScore: Int,
  val temperatureHealthScore: Int,
  val lightHealthScore: Int,
  val primaryIssue: String?,
  val recommendation: String,
  val requiresRelayWatering: Boolean
) {
  companion object {
    fun evaluate(sensorData: SensorData?, thresholds: EcoThresholds = EcoThresholds(), isNodePoweredOn: Boolean = true): PlantHealthAnalysis {
      if (!isNodePoweredOn) {
        return PlantHealthAnalysis(
          overallScore = 0,
          tier = PlantHealthTier.STRESSED,
          vitalitySummary = "Node Power OFF",
          moistureHealthScore = 0,
          temperatureHealthScore = 0,
          lightHealthScore = 0,
          primaryIssue = "Hardware node is shut down.",
          recommendation = "Power on the node to monitor environmental metrics.",
          requiresRelayWatering = false
        )
      }

      if (sensorData == null) {
        return PlantHealthAnalysis(
          overallScore = 75,
          tier = PlantHealthTier.HEALTHY,
          vitalitySummary = "Awaiting Telemetry",
          moistureHealthScore = 75,
          temperatureHealthScore = 75,
          lightHealthScore = 75,
          primaryIssue = null,
          recommendation = "Connecting to device sensors for health diagnosis...",
          requiresRelayWatering = false
        )
      }

      // Soil Moisture (0 - 100)
      val soilAvg = sensorData.soilAverage
      val moistureScore: Int = if (soilAvg != null) {
        when {
          soilAvg < thresholds.soilDryPercent -> 35
          soilAvg in thresholds.soilDryPercent..thresholds.soilTargetPercent -> 95
          soilAvg in (thresholds.soilTargetPercent + 1)..80 -> 80
          else -> 45 // Overwatered/saturated
        }
      } else {
        70
      }

      // Temperature (ideal 20°C - 28°C)
      val temp = sensorData.temperatureC
      val tempScore: Int = if (temp != null) {
        when {
          temp in 20.0..28.0 -> 95
          temp in 16.0..19.9 || temp in 28.1..thresholds.highTempAlertThresholdC -> 75
          temp > thresholds.highTempAlertThresholdC -> 30 // Heat stress
          else -> 40 // Cold stress
        }
      } else {
        75
      }

      // Light level (ideal 25% - 75%)
      val lightPct = sensorData.lightPercent
      val lightScore: Int = if (lightPct != null) {
        when {
          lightPct in 25..75 -> 95
          lightPct in 15..24 || lightPct in 76..85 -> 80
          lightPct < 15 -> 50 // Too dark
          else -> 60 // Too bright
        }
      } else {
        75
      }

      val overall = ((moistureScore * 0.5) + (tempScore * 0.3) + (lightScore * 0.2)).toInt().coerceIn(0, 100)

      val tier = when {
        overall >= 85 -> PlantHealthTier.THRIVING
        overall >= 70 -> PlantHealthTier.HEALTHY
        overall >= 50 -> PlantHealthTier.ATTENTION_NEEDED
        else -> PlantHealthTier.STRESSED
      }

      val primaryIssue = when {
        soilAvg != null && soilAvg < thresholds.soilDryPercent -> "Soil moisture critical (< ${thresholds.soilDryPercent}%)"
        soilAvg != null && soilAvg > 85 -> "Soil saturated (potential root rot risk)"
        temp != null && temp > thresholds.highTempAlertThresholdC -> "Heat stress (> ${thresholds.highTempAlertThresholdC}°C)"
        temp != null && temp < 14.0 -> "Cold stress (< 14°C)"
        lightPct != null && lightPct < 15 -> "Low light levels"
        else -> null
      }

      val rec = when {
        sensorData.isRaining == true -> "Natural rainfall in progress. Automated watering paused."
        soilAvg != null && soilAvg < thresholds.soilDryPercent -> "Soil is dry. Turn ON irrigation relay or initiate auto schedule."
        temp != null && temp > thresholds.highTempAlertThresholdC -> "High canopy temperature. Consider shade cloth or misting."
        soilAvg != null && soilAvg > 85 -> "Moisture high. Allow soil to drain before next watering."
        else -> "Optimal canopy balance. Continue current schedule."
      }

      val needsWater = (sensorData.isRaining != true) && (soilAvg != null && soilAvg < thresholds.soilDryPercent)

      return PlantHealthAnalysis(
        overallScore = overall,
        tier = tier,
        vitalitySummary = if (primaryIssue == null) "Optimal Vigor" else "Action Required",
        moistureHealthScore = moistureScore,
        temperatureHealthScore = tempScore,
        lightHealthScore = lightScore,
        primaryIssue = primaryIssue,
        recommendation = rec,
        requiresRelayWatering = needsWater
      )
    }
  }
}
