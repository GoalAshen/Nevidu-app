package com.smart.plant.guardian.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smart.plant.guardian.data.model.DailySchedule

@Composable
fun DailyScheduleCard(
  schedule: DailySchedule,
  canControl: Boolean,
  onUpdateSchedule: (DailySchedule) -> Unit,
  modifier: Modifier = Modifier
) {
  var enabled by remember(schedule) { mutableStateOf(schedule.enabled) }
  var startHour by remember(schedule) { mutableFloatStateOf(schedule.startHour.toFloat()) }
  var startMinute by remember(schedule) { mutableFloatStateOf(schedule.startMinute.toFloat()) }
  var duration by remember(schedule) { mutableFloatStateOf(schedule.durationMinutes.toFloat()) }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("daily_schedule_card"),
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder()
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.tertiaryContainer,
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.Schedule,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onTertiaryContainer,
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Column {
            Text(
              text = "Automated Irrigation Timer",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Daily autonomous watering window",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Switch(
          checked = enabled,
          onCheckedChange = {
            if (canControl) {
              enabled = it
              onUpdateSchedule(schedule.copy(enabled = it))
            }
          },
          enabled = canControl,
          modifier = Modifier.testTag("schedule_enable_switch")
        )
      }

      Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          val h = startHour.toInt()
          val m = startMinute.toInt()
          val timeStr = "%02d:%02d".format(h, m)

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Start Time:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(timeStr, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
          }
          Slider(
            value = startHour,
            onValueChange = {
              if (canControl) {
                startHour = it
                onUpdateSchedule(schedule.copy(startHour = it.toInt()))
              }
            },
            enabled = canControl && enabled,
            valueRange = 0f..23f,
            steps = 22
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Run Duration:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("${duration.toInt()} min", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
          }
          Slider(
            value = duration,
            onValueChange = {
              if (canControl) {
                duration = it
                onUpdateSchedule(schedule.copy(durationMinutes = it.toInt()))
              }
            },
            enabled = canControl && enabled,
            valueRange = 1f..60f,
            steps = 58
          )
        }
      }
    }
  }
}
