# Smart Plant Guardian

**Package Name:** `com.smart.plant.guardian`  
**Application ID:** `com.smart.plant.guardian`  
**Target Platform:** Android (minSdk 21, compileSdk 36, targetSdk 36)  
**Architecture:** Jetpack Compose + Clean Architecture (MVVM) + Kotlin Coroutines & Flow

---

## 1. Overview & Branding
Smart Plant Guardian is an environmental monitoring and micro-climate irrigation management application. It provides real-time multi-depth soil moisture sensing, automated pump actuation, fleet-wide node management, and an administrative panel with role-based access control.

### App Launcher & Visual Identity
- **Adaptive Launcher Icon:** Shield containing a two-leaf sprouting plant in fresh green (`#3DDC84`) with an aqua water drop (`#4FC3F7`) on a deep forest green background (`#0B3D2E`).
- **Themed / Monochrome Icons:** Supports Android 13+ wallpaper-based monochrome icon rendering (`ic_launcher_monochrome.xml`).
- **Dynamic Theming (Material You):** On Android 12+ (API 31+), the app automatically uses `dynamicLightColorScheme` and `dynamicDarkColorScheme`. On Android 5.0 through 11 (API 21-30), it gracefully falls back to a nature green/aqua Material 3 palette.
- **NO CSV EXPORT:** All CSV export operations, file provider configurations, storage permissions, and UI buttons have been completely removed.

---

## 2. Firebase Configuration & Setup Steps

The app connects directly to your Firebase project. Sign-in is required; there is no demo or guest mode.

### Setup Steps:
1. **Create a Firebase Project:**
   Go to the [Firebase Console](https://console.firebase.google.com) and create a project.
2. **Enable Firebase Authentication:**
   In Firebase Console -> Build -> Authentication -> Sign-in method, enable **Email/Password**.
3. **Create a Realtime Database (RTDB):**
   In Firebase Console -> Build -> Realtime Database, create a database in your preferred cloud region.
4. **Obtain Project Keys:**
   - **Database URL:** e.g., `https://<project-id>-default-rtdb.firebaseio.com`
   - **Web API Key:** Found in Project Settings -> General -> Web API Key.
   - **Project ID:** Found in Project Settings -> General -> Project ID.
   - **App ID:** Android App ID in format `1:123456789:android:abcdef`.
5. **Configure In-App:**
   - Open Smart Plant Guardian. On first launch the setup screen shows the **Firebase RTDB & Backend** card.
   - Enter your Database URL, Web API Key, App ID, and Project ID.
   - Tap **Save Firebase Configuration**.
   - Tap **Sign in or register**. Upon successful authentication, live RTDB listeners activate.
   - Alternatively, place a valid `google-services.json` in the `app/` folder.

### First Admin Account Bootstrap:
1. Register a new user account through the in-app Sign-Up form (or Firebase Console).
2. By default, newly registered accounts are assigned `role: "viewer"` and `status: "pending"`.
3. To bootstrap the **first admin**:
   - In the Firebase Console, navigate to **Realtime Database** -> `/users/{uid}`.
   - Change `role` to `"admin"` and `status` to `"active"`.
4. The user now has full administrative privileges and can access the Admin Panel via the shield icon in the top app bar.

---

## 3. Realtime Database Security Rules

Copy and paste the following rules into your Firebase Realtime Database rules tab:

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "auth != null && ($uid === auth.uid || root.child('users').child(auth.uid).child('role').val() === 'admin')",
        ".write": "auth != null && (
          root.child('users').child(auth.uid).child('role').val() === 'admin' ||
          (!data.exists() && $uid === auth.uid && newData.child('role').val() === 'viewer' && newData.child('status').val() === 'pending')
        )"
      }
    },
    "devices": {
      "$deviceId": {
        "sensors": {
          ".read": "auth != null && (
            root.child('users').child(auth.uid).child('role').val() === 'admin' ||
            root.child('devices').child($deviceId).child('members').child(auth.uid).val() === true
          )",
          ".write": "auth != null && root.child('users').child(auth.uid).child('role').val() === 'device'"
        },
        "status": {
          ".read": "auth != null && (
            root.child('users').child(auth.uid).child('role').val() === 'admin' ||
            root.child('devices').child($deviceId).child('members').child(auth.uid).val() === true
          )",
          ".write": "auth != null && root.child('users').child(auth.uid).child('role').val() === 'device'"
        },
        "history": {
          ".read": "auth != null && (
            root.child('users').child(auth.uid).child('role').val() === 'admin' ||
            root.child('devices').child($deviceId).child('members').child(auth.uid).val() === true
          )",
          ".write": "auth != null && root.child('users').child(auth.uid).child('role').val() === 'device'"
        },
        "commands": {
          ".read": "auth != null && (
            root.child('users').child(auth.uid).child('role').val() === 'device' ||
            root.child('users').child(auth.uid).child('role').val() === 'admin' ||
            root.child('devices').child($deviceId).child('members').child(auth.uid).val() === true
          )",
          ".write": "auth != null && (
            root.child('users').child(auth.uid).child('status').val() === 'active' && (
              root.child('users').child(auth.uid).child('role').val() === 'admin' ||
              root.child('users').child(auth.uid).child('role').val() === 'operator'
            )
          )"
        },
        "settings": {
          ".read": "auth != null && (
            root.child('users').child(auth.uid).child('role').val() === 'device' ||
            root.child('users').child(auth.uid).child('role').val() === 'admin' ||
            root.child('devices').child($deviceId).child('members').child(auth.uid).val() === true
          )",
          ".write": "auth != null && (
            root.child('users').child(auth.uid).child('status').val() === 'active' && (
              root.child('users').child(auth.uid).child('role').val() === 'admin' ||
              root.child('users').child(auth.uid).child('role').val() === 'operator'
            )
          )"
        },
        "members": {
          ".read": "auth != null",
          ".write": "auth != null && root.child('users').child(auth.uid).child('role').val() === 'admin'"
        }
      }
    },
    "audit": {
      ".read": "auth != null && root.child('users').child(auth.uid).child('role').val() === 'admin'",
      "$auditId": {
        ".write": "auth != null && root.child('users').child(auth.uid).child('status').val() === 'active'"
      }
    }
  }
}
```

---

## 4. Hardware Data Contract (`/devices/{deviceId}/...`)

| Path | Type / Keys | Read Permissions | Write Permissions | Description |
|---|---|---|---|---|
| `sensors` | `temperatureC`, `humidityPercent`, `soilZone1`, `soilZone2`, `soilZone3`, `lightPercent` (0-100; fallback `lightLux/1000`), `isRaining`, `batteryPercent`, `solarCharging` (optional), `lastSeenEpochMs` | Active Members & Admin | Device Account (`role: device`) | Live telemetry. Missing values display as `"--"`. No fake defaults. |
| `status` | `pumpOn`, `mode` (`"AUTO"`/`"MANUAL"`), `activeRunSeconds` | Active Members & Admin | Device Account (`role: device`) | Real device state. Used for 10-second command confirmation watchdog. |
| `commands` | `power`, `pump`, `mode`, `buzzer`, `speaker`, `ledRed`, `ledBlue`, `ledGreen`, `ledYellow` | Device Account & Members | Active Operators & Admins | Remote actuation commands written by mobile app. |
| `settings` | `soilDryPercent`, `soilTargetPercent`, `highTempAlertThresholdC`, `lowBatteryAlertPercent`, `maxPumpRunTimeMinutes`, `schedule` (`enabled`, `startHour`, `startMinute`, `durationMinutes`, `activeDays`) | Device Account & Members | Active Operators & Admins | Device operational thresholds and irrigation timetable. |
| `history` | List of items: `timestampMs`, `tempC`, `humidity`, `soilAvg`, `zone1`, `zone2`, `zone3`, `lightPercent`, `batteryPercent` | Active Members & Admin | Device Account only (limitToLast 200) | **Read-only** for mobile application. App never writes history. |

---

## 5. Admin Panel & Roles
- **Roles:**
  - `admin`: Full system control (user approvals, role elevation, member assignment, global thresholds, activity logs, emergency controls).
  - `operator`: Hardware control (toggling relays, modes, hardware alarms, schedule configuration).
  - `viewer`: Read-only access to sensor telemetry and status. Control buttons are hidden or disabled.
  - `device`: Hardware ESP32 account writing sensors/status and reading commands.
- **Statuses:**
  - `pending`: Newly registered accounts. Displays "Waiting for admin approval" screen until activated.
  - `active`: Normal authenticated access.
  - `blocked`: Revoked access. Displays "Access disabled" notice.
- **Emergency Fleet Controls:**
  - **Turn all pumps OFF:** Broadcasts emergency relay shutdown across all nodes.
  - **Force MANUAL mode:** Overrides autonomous loops on all nodes.
- **Audit Logging:** Every administrative and hardware change is logged to `/audit/{pushId}` with `uid`, `email`, `action`, `deviceId`, and `timestampMs`.

---

## 6. Android 5.0+ Compatibility (minSdk 21)
- **Desugaring:** `isCoreLibraryDesugaringEnabled = true` with `desugar_jdk_libs:2.0.4` enables Java 8+ APIs (`java.time`, streams) on Android 5.0 through 7.1.
- **Firebase BoM 32.8.1:** Native `minSdk 21` support for Firebase Auth and Realtime Database.
- **API Guards:**
  - Dynamic Wallpaper Colors: Guarded with `Build.VERSION.SDK_INT >= 31`.
  - Notification Channels: Guarded with `Build.VERSION.SDK_INT >= 26` via `NotificationHelper`.
  - POST_NOTIFICATIONS runtime permission: Guarded with `Build.VERSION.SDK_INT >= 33`.
  - Edge-to-Edge: Handled via `enableEdgeToEdge()` and Compose `WindowInsets`.
