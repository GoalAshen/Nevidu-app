# Implementation Plan: EcoControl Node Pairing & Multi-Language Support

Simplify and streamline the EcoControl interface, introduce an interactive Bluetooth LE device pairing and Wi-Fi provisioning screen, and implement full multi-language localization supporting 9 languages with a first-time welcome language selector.

## User Review & Critical Decisions

> [!IMPORTANT]
> **Confirmed Choices from Phase 1:**
> - **Pairing Mechanism:** Bluetooth Low Energy (BLE) scanning with Wi-Fi credential provisioning and hardware information retrieval (Node ID, MAC Address, Signal RSSI, Firmware, and Live Telemetry Handshake).
> - **Language Selection Flow:** Dedicated welcome language picker presented on first launch, with the ability to switch languages anytime via the top navigation bar and settings.
> - **Simplified & Neat Layout:** Clean, decluttered card layouts with higher spacing density, unified typography, and simplified sensor readouts for effortless monitoring.

---

## 1. Overview & Core Concept

- **Bluetooth LE Pairing Screen:**
  - Dedicated step-by-step pairing wizard:
    1. **Scan:** Discover nearby environmental nodes with live signal strength meters.
    2. **Connect & Query Info:** Retrieve hardware specifications (hardware MAC, device identifier, firmware version, battery health, and onboard sensor verification).
    3. **Provision Wi-Fi:** Enter target 2.4GHz network SSID and password to transfer network credentials to the node.
    4. **Confirmation & Fleet Registration:** Confirm cloud connection test and automatically register the new node into the active fleet.
  - Realistic simulation mode support: Allows users to test and preview the complete Bluetooth scanning, connection handshake, and provisioning sequence without requiring physical hardware present.

- **Multi-Language Localization (9 Languages):**
  - **English** (`en`)
  - **Sinhala** (සිංහල - `si`)
  - **Tamil** (தமிழ் - `ta`)
  - **French** (Français - `fr`)
  - **Spanish** (Español - `es`)
  - **Portuguese** (Português - `pt`)
  - **Hindi** (हिन्दी - `hi`)
  - **Japanese** (日本語 - `ja`)
  - **Korean** (한국어 - `ko`)
  - Centralized string dictionary (`EcoTranslations.kt`) covering all screens: Dashboard, Controls, Charts, Logs, Pairing, Fleet, and Firebase settings.
  - Persistent language preference state in ViewModel with immediate dynamic recomposition.

- **Simplified & Neat Interface:**
  - Reduced visual clutter by eliminating redundant secondary metrics and grouping related sensors into neat, glanceable cards.
  - Generous touch targets (min 48dp), rounded M3 corners (16–20dp), and smooth emerald/cyan theme accents.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **First-Time Launch & Language Onboarding:**
   - On first launch, a welcoming bottom sheet or modal introduces EcoControl in the user's native tongue.
   - User selects from 9 language cards with native script titles and national flag emblems.
   - The app dynamically switches all labels, cards, alerts, and navigation buttons.

2. **Node Pairing Flow:**
   - User taps **"Pair Node"** in the top bar or fleet tab.
   - An animated radar wave scans for nearby devices (`NODE-E82`, `NODE-9A4`, `NODE-1F0`, or new unconfigured nodes).
   - User taps a discovered node -> app connects via BLE and retrieves hardware diagnostics.
   - User inputs Wi-Fi credentials -> progress animation validates connection -> node is added to active monitoring.

3. **Simplified Dashboard & Navigation:**
   - 5 streamlined tabs: **Dashboard**, **Controls**, **Charts**, **Pair & Fleet**, and **Settings & Alerts**.
   - Language selector pill prominently positioned in the top bar for quick 1-tap switching.

```
┌────────────────────────────────────────────────────────┐
│  🌿 EcoControl              🌐 [සිංහල ▾]  🔔 (2)  🌙  │
├────────────────────────────────────────────────────────┤
│  ┌──────────────────────────────────────────────────┐  │
│  │ 🟢 Greenhouse Alpha  [NODE-E82]      ● ONLINE    │  │
│  │ Last seen: 2s ago • Signal: -54 dBm              │  │
│  └──────────────────────────────────────────────────┘  │
│                                                        │
│  ┌──────────────────────┐    ┌──────────────────────┐  │
│  │ 🌡️ Climate           │    │ 💧 Soil Moisture     │  │
│  │  25.4°C  •  63.8% RH │    │  Zone 1: 48% (Good)  │  │
│  │  Optimal Conditions  │    │  Zone 2: 31% (Dry)   │  │
│  └──────────────────────┘    │  Zone 3: 76% (Wet)   │  │
│                              └──────────────────────┘  │
│  ┌──────────────────────┐    ┌──────────────────────┐  │
│  │ ⚡ Power & Solar     │    │ ☀️ Light & Rain      │  │
│  │  91% • 4.14V (16.8W) │    │  48k Lux • Dry       │  │
│  └──────────────────────┘    └──────────────────────┘  │
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │ ⚡ 12V Irrigation Pump: [ OFF ]       Mode: AUTO │  │
│  └──────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────┤
│  [Dashboard] [Controls] [Charts] [Pair Node] [Settings]│
└────────────────────────────────────────────────────────┘
```

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dynamic In-App Localization Layer (`EcoTranslations.kt`)**
  - *Chosen Approach:* Implement a type-safe Kotlin translation dictionary supporting all 9 languages with immediate in-memory reactive state.
  - *Why:* Android OS locale switching typically requires restarting activities or modifying device-wide system settings. An in-app localization state flow provides instantaneous runtime language switching on the fly without interrupting ongoing telemetry streams or user tasks.
  - *Coverage:* Complete coverage for all labels, sensor titles, statuses (Online/Offline, Dry/Good/Wet, Auto/Manual), alerts, button text, and pairing wizard prompts across Sinhala, Tamil, French, Spanish, Portuguese, Hindi, Japanese, Korean, and English.

- **Decision 2: Seamless BLE Hardware & Simulation Mode Handshake**
  - *Chosen Approach:* Implement a dual-mode pairing engine that checks for Android Bluetooth permissions (`BLUETOOTH_SCAN`, `BLUETOOTH_CONNECT`) and runs realistic simulated BLE discovery and provisioning when in demo mode or when physical nodes are not nearby.
  - *Why:* Ensures the user can immediately test and evaluate the entire pairing flow on the AI Studio streaming emulator, while retaining real Android Bluetooth API readiness.

- **Decision 3: Consolidated Navigation Hierarchy (5 Tabs)**
  - *Chosen Approach:* Merge Fleet Management with the new BLE Pairing Wizard into a unified **"Pair & Fleet"** tab, and combine Event Logs with Settings & System Alerts into **"Settings & Alerts"**.
  - *Why:* Prevents bottom bar overcrowding while keeping touch targets comfortably large (>= 48dp) and clean.

---

## 4. Technical Architecture & Data Strategy

```
┌───────────────────────────────────────────────────────────────────────────┐
│                           EcoControl Applet                               │
│                                                                           │
│  ┌──────────────────────┐                     ┌────────────────────────┐  │
│  │   EcoTranslations    │◄────────────────────┤  LanguagePreference    │  │
│  │ (EN, SI, TA, FR, ES, │                     │ (Selected Language,    │  │
│  │  PT, HI, JA, KO)     │                     │  FirstLaunch Flag)     │  │
│  └──────────┬───────────┘                     └───────────┬────────────┘  │
│             │                                             │               │
│             ▼                                             ▼               │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                         EcoViewModel                                │  │
│  │  - languageState: StateFlow<EcoLanguage>                            │  │
│  │  - pairingState: StateFlow<BlePairingState>                         │  │
│  │  - sensorData, relayState, alerts, telemetryHistory                 │  │
│  └──────┬───────────────────────────────┬──────────────────────────────┘  │
│         │                               │                                 │
│         ▼                               ▼                                 │
│  ┌──────────────────────────────┐     ┌────────────────────────────────┐  │
│  │        EcoRepository         │     │     BlePairingManager          │  │
│  │ - Multi-device fleet state   │     │ - BLE Scanning & RSSI Meter    │  │
│  │ - Physics & telemetry engine │     │ - Handshake & Info Extraction  │  │
│  │ - Firebase RTDB paths        │     │ - Wi-Fi Credential Push        │  │
│  └──────────────────────────────┘     └────────────────────────────────┘  │
│                                                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                           Compose UI                                │  │
│  │  - WelcomeLanguageModal: First-time language selector               │  │
│  │  - NodePairingScreen: Step-by-step discovery & Wi-Fi setup          │  │
│  │  - SimplifiedDashboard: Clean, glanceable sensor cards              │  │
│  │  - SensorHistoryGraphCard: Multi-sensor timeline charts             │  │
│  │  - ControlsScreen: Relay, sliders, diagnostic tests, daily schedule │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────────────────────┘
```

### Data Structures & State Management
- `EcoLanguage`: Enum with language code, native title (`සිංහල`, `தமிழ்`, `Français`, `Español`, `Português`, `हिन्दी`, `日本語`, `한국어`, `English`), and flag icon.
- `BlePairingState`: Idle, Scanning, Connecting, QueryingInfo, ProvisioningWifi, Success, Failed.
- `DiscoveredDevice`: Identifier, Device Name, RSSI dBm, MAC Address, Hardware Type, Firmware Version.

### Test & Verification Plan
- Unit tests validating translation key completeness across all 9 languages.
- Unit tests verifying pairing state machine transitions and Wi-Fi credential validation.
- Robolectric test suite execution (`gradle :app:testDebugUnitTest`).
- Full applet compilation check (`compile_applet`).
